# Source Archive and Design History

## Build-handoff update

[New discussion and asset sources](../../Reference_Material/Build_Handoff_2026-09-21/README.md) add five main turns through answer 403 and the final readiness recap, bringing the main archive to **438 turns**. They also preserve naming/modeling discussions and the recovered recent Grimnir environment turns. The latest main exchange has no pending numbered question.

## Current source coverage

[September 21 milestone discussion](../../Reference_Material/Discussion_2026-09-21/README.md) adds 53 turns and five supplied visual references. The [complete design conversation](../../Morkahja-Concept-Sources.md) contains **433 turns through answer 399**, with **question 400 awaiting an answer**. [Reconciliation](Update_Through_Answer_399.md) identifies current rules, replaced alternatives and unresolved details.

The dated entries below describe earlier snapshots.

## Prototype review sources

[September 20 review](../../Reference_Material/Prototype_Review_2026-09-20/README.md) preserves 18 new main turns, planning discussions and the original first-playable source references. The main conversation now contains 380 turns through answer 358; question 359 is pending.

## Latest discussion update

[New sources and per-turn coverage](../../Reference_Material/Discussion_2026-09-18/README.md) contain 100 new main turns and the three related conversations. [Reconciliation through answer 341](Update_Through_Answer_341.md) records decisions and superseded alternatives. The main source conversation is complete through answer 341; question 342 is pending.

The topic chapters describe the current concept. This index holds the supporting discussion, earlier wording and development history.

## Original material

- [Complete design conversation](../../Morkahja-Concept-Sources.md): the retained source conversation through answer 399.
- [Grimnir lore collection](../../Reference_Material/Grimnir_Lore_2026-09-14/README.md): local worldbuilding articles, conversations and reference records.
- [Chapters before the editorial cleanup](../../Reference_Material/Before_Editorial_Cleanup/README.md): exact copies of all 41 previous documents, including their quotations, examples, citations and revision notes.

## Development records

- [Open questions](Open_Questions.md)
- [Ideas and superseded proposals](Ideas_and_Superseded_Proposals.md)
- [Design decisions](Design_Decisions.md)
- [Conversation coverage and former chapter map](Conversation_Coverage_and_Structure_Map.md)
- [Changelog](Changelog.md)

## Reading historical material

Earlier records contain vocabulary and rules subsequently replaced during the discussion. Their dates describe the record's original scope. Current topic chapters incorporate the later decisions, while open choices remain in development notes.

The editorial cleanup preserves the source files and the complete earlier chapters. Historical examples can therefore be retrieved without putting the interview process back into the main articles.
