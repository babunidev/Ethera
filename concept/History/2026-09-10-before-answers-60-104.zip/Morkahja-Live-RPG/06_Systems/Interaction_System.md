# Interaction System

**Status:** Established concept, updated 2026-09-10. Later user decisions supersede earlier brainstorms; unresolved details are marked.

## Two paired vocabularies

| Persistent pairing | Situational pairing |
| --- | --- |
| Desire ↔ Trait | Need ↔ Shard |
| What a character seeks meets a quality in the world. | A current requirement meets relevant functional knowledge. |

Every trait/desire and shard/need has a defined counterpart in the design vocabulary. Pairing is a content-design rule, not a promise that a solution is already nearby or in the player's knowledge.

## Meaningful context

Traits belong to people, creatures, items, and places. A bear can carry Bear; a place or object can carry a sought quality. The same pairing system supports social interaction, exploration, combat, side quests, and destiny.

Relationships, roles, current state, equipment, and proximity shape which matching opportunities are actually usable. A character can possess a trait they also desire in others.

## In-person interaction

Character-to-character opportunities appear in close proximity. No telepathic or global knowledge synchronization is assumed. When one person has newer knowledge than another for the same node, the match offers a cultural knowledge-exchange action. Players choose to execute it; standing nearby does not instantly synchronize their information.

Performed social interactions can create relationship shards and open deeper connections: recognition, sympathy, and trust. No compatibility means deeper interaction may not appear; it does not create hatred or negative reputation in the initial design.

## Actions beyond matches

The system also has a universal embodied baseline. Ordinary movement and touching do not require a special personal trait or a paired desire. Traits and roles expand that foundation; injuries may restrict it. Combat and incapacitation use state changes to alter available interactions.

## Initial scope

Aim for distinct interactions for specific pairs, starting with a manageable culturally appropriate library. Detailed catalogues and exact action eligibility remain open.

See [Relationships](../04_Community/Relationships.md), [Knowledge Shards](Knowledge_Shards.md), and [Baseline Actions](../03_Characters/Baseline_Actions.md).

## Source

[Morkahja live RPG](https://chatgpt.com/c/6aa08555-1c60-83eb-ae68-d3555edd8d7f), design discussion through 2026-09-10, interview answers 31–59. See the [preserved conversation](../../Morkahja-Concept-Sources.md) for exact wording and intermediate ideas. Examples are illustrative, not exhaustive implementation lists.
