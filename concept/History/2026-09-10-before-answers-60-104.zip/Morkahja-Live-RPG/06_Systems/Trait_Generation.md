# Trait Generation

**Status:** Established concept, updated 2026-09-10; later user corrections take precedence.

## Confirmed draw

Draw 9 traits randomly from each parent and 9 from the full pool, for 27 birth traits. The global draw spans all trait types. Do not enforce a balanced Combat/Trickery/Aid/Social spread or choose a role first and manufacture traits to fit it.

## Interpret after drawing

The combination informs appearance and personality. At adulthood, when all birth traits are active, it informs the social role and then related destiny and side quests.

## Activation and growth

Birth traits begin partly latent. An initial 9 active traits was suggested; the rest unlock through growth. Experience can add permanent binary traits during childhood and adulthood. There is no lifetime cap of 27 and no routine trait loss.

## Unresolved edge cases

- Duplicate draws when parents share traits or the global pool repeats them.
- Whether “27” must always mean 27 distinct traits.
- Which parental traits are eligible, including those gained through life.
- Contradictory qualities and their interpretation without imposing rejected category balancing.
- Exact childhood activation steps and adult role recalculation.


## Update — 2026-09-10

A separate desire-generation target uses 9 inherited total, 9 birth-generated, and 9 experiential Desires. Traits and Desires may overlap in one character. The paired vocabulary also extends to world traits, whose state rules differ from permanent personal acquisition. Baseline embodiment can be represented as underlying traits, without any established change to the 27 personal birth-trait count. See [Desires](../03_Characters/Desires.md).

## Source

Project conversation: [Morkahja live RPG](https://chatgpt.com/c/6aa08555-1c60-83eb-ae68-d3555edd8d7f), retrieved 2026-09-09 and updated through 2026-09-10. The complete retrieved conversation is preserved in [the source archive](../../Morkahja-Concept-Sources.md). Examples illustrate the concept; they are not exhaustive content lists.
