# Environmental Guidance

**Status:** Established concept, updated 2026-09-10. Later user decisions supersede earlier brainstorms; unresolved details are marked.

## Signs in the world

Navigation uses natural and magical signs: wind, light, a rising bird, a gust of magic, or the directional pull of a Grimnir's floating stones. There are no map markers, compass directions rendered as UI arrows, or objective-pointer overlays.

## Prioritized Need

The player inspects the character's Needs and relevant Shards, then prioritizes one Need. This shifts which objective the signs guide toward. A player can choose a different side quest or thread for a session rather than always following the main destiny.

**Prioritized Need + relevant Shard = guidance toward the current objective.**

Missing relevant knowledge leads to consultation with a person or cultural hub. The player does not need to see the full dependency chain to follow its next actionable requirement.

## Keep it simple

Prioritization is mostly an internal focus choice, with subtle reaction at most. Do not add a separate emotion-response layer, shard-quality ranking, precision tiers, or guidance-strength system.

Knowledge can still be stale until updated through interaction. The simplification removes additional quality mechanics; it does not make all knowledge omniscient.

Compatible characters can share a direction or strengthen a common pull, as in the earlier concept. Exact sign timing and accessibility remain open.

See [Diegetic Interface](Diegetic_Interface.md) and [Needs](../03_Characters/Needs.md).

## Source

[Morkahja live RPG](https://chatgpt.com/c/6aa08555-1c60-83eb-ae68-d3555edd8d7f), design discussion through 2026-09-10, interview answers 31–59. See the [preserved conversation](../../Morkahja-Concept-Sources.md) for exact wording and intermediate ideas. Examples are illustrative, not exhaustive implementation lists.
