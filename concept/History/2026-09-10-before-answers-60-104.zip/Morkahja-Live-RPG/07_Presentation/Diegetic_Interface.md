# Diegetic Interface

**Status:** Established concept, updated 2026-09-10. Later user decisions supersede earlier brainstorms; unresolved details are marked.

The world and character should carry as much information as possible, with minimal interface during play. Bodies express well-being through size, brightness, transparency, strength, and definition; environmental signs express direction.

## Explicit character screen

The character screen shows **Traits, Desires, Needs, and Shards**. Players can inspect each Need and its relevant known shards, see what the character currently requires, and choose a priority.

The current immediate requirement is sufficient; the player does not see the complete dependency web. They can switch to another Need or side quest. Missing information prompts a cultural knowledge-hub visit or an appropriate interpersonal exchange.

## Priority and guidance

Choosing a Need changes the world signs to follow its relevant knowledge. No map markers, compass arrows, elaborate guidance tiers, or separate visible emotion system are introduced.

## Other contextual UI

Character selection tells the story of an available life. Queue offers provide recaps, and spectator inspection can expose permitted lore. These screens coexist with the aim of minimal in-world UI.

Combat offers timely state-dependent interactions while the game handles engaged facing and positioning. The exact display of those options remains unspecified. Injury is functional state, not a commitment to a conventional health-bar interface.

There is no player voice or text chat. Social and knowledge exchanges are actions within the world.

See [Combat](../05_Gameplay/Combat.md) and [Environmental Guidance](Environmental_Guidance.md).

## Source

[Morkahja live RPG](https://chatgpt.com/c/6aa08555-1c60-83eb-ae68-d3555edd8d7f), design discussion through 2026-09-10, interview answers 31–59. See the [preserved conversation](../../Morkahja-Concept-Sources.md) for exact wording and intermediate ideas. Examples are illustrative, not exhaustive implementation lists.
