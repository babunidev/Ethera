# Open Questions

**Status:** Established concept, updated 2026-09-10. Later user decisions supersede earlier brainstorms; unresolved details are marked.

## Latest unanswered question

Should elemental baseline abilities be available during childhood and develop with maturity, or should some unlock at adulthood? This is interview Question 60; the retrieved conversation has no answer yet.

## Character generation and development

- How are the 9 inherited Desires divided between parents? How do the 9 experiential Desires emerge, especially when role is mentioned but roles start at adulthood?
- How are duplicated or incompatible personal trait draws handled, and are all 27 distinct?
- Which parental learned traits can be inherited, and how do childhood gains affect adult roles?
- What are the exact childhood stages, duration, and initial active-trait count?
- What are each culture's roles, baseline elemental abilities, and initial action library?

## Knowledge and interaction implementation

- How are same-node topics identified when a node contains several creatures/items? How are newer or conflicting reports resolved?
- What exact actions contribute knowledge to a hub? The current copying simplification has no mandatory personal clearing rule.
- What are the relationship-shard thresholds for recognition, sympathy, and trust?
- What makes an action available for a particular pair, and how much initial interaction variety is feasible?

## Combat

- How are timing windows, multiple opponents, group encounters, and lock transitions handled?
- Which broad injury states and action restrictions ship first? What are healing and incapacity thresholds?
- How does injury or capture connect to essence, corruption, and judgment at Atranor?

## World and objectives

- When is destiny content prepared relative to adulthood activation?
- How do impossible goals, destroyed items, vanished exchange partners, and cyclic dependencies recover without imposing the rejected fixed depth cap?
- How do nodes determine slot vacancy and preserve other active contents during repopulation?
- How do final destiny completion, magic's ancient chronology, and early cultural institutions work?

## Remaining production questions

Offline speed, population/server scale, queue timings and priority details, spectator information access, property permissions, final camera inputs, platform, adult-content/life-stage boundaries, and the optional reflective diary remain open.

## Resolved today

Shard weight/capacity and oldest-first forgetting were rejected. Traits/Desires and Shards/Needs are distinct pairs. Desires target traits even on world entities and may overlap the holder's own traits. Knowledge updates require interaction. Personal obsolete shards are replaced; collective history is retained. Nodes keep current state with persistent geography and multiple slots. Exchange chains have no fixed depth limit. Players prioritize Needs in a character screen; navigation has no map markers or compass arrows and no quality-tier subsystem. Social relationships start neutral/positive. Combat uses timed actions, broad injuries, and state-based alternatives for both players and AI. Ordinary actions have a shared baseline.

## Source

[Morkahja live RPG](https://chatgpt.com/c/6aa08555-1c60-83eb-ae68-d3555edd8d7f), design discussion through 2026-09-10, interview answers 31–59. See the [preserved conversation](../../Morkahja-Concept-Sources.md) for exact wording and intermediate ideas. Examples are illustrative, not exhaustive implementation lists.
