# Design Decisions

**Status:** Established concept, updated 2026-09-10; later user corrections take precedence.

Later explicit user statements override earlier brainstorms and assistant summaries.

| ID | Current decision | Conversation basis |
| --- | --- | --- |
| D001 | Persistent world characters are temporarily inhabited; players do not own avatars. | Opening concept. |
| D002 | Shared multiplayer RPG with autonomous settlements; no building management by players. | Explicit settlement-control correction. |
| D003 | Population growth adds available character slots. | Community and reproduction discussion. |
| D004 | Objects exist before objectives and remain afterward unless physically used or changed. | Bear claw and earlier-loot examples. |
| D005 | Objectives follow goals and existing objects, not mandatory repeated kills. | Dynamic bear objective example. |
| D006 | Reuse vacant nodes and add new content with every destiny. | Expansion and repopulation clarification. |
| D007 | Traits are binary and never routinely lost. | Interview answers on trait ranks and decay. |
| D008 | Birth pool is 27 traits: 9 + 9 parental and 9 global, without category balancing. | Trait-count and random-draw answers. |
| D009 | Childhood is playable; all birth traits active by adulthood. | Growth explanation. |
| D010 | Role and destiny begin at adulthood. | Explicit later timing corrections. |
| D011 | Roles grant abilities and unique interactions; exact lists are culture-specific and deferred. | Hunter tracking and culture discussions. |
| D012 | Side quests can add relevant permanent traits. | Climber and herb-learning examples. |
| D013 | AI maintains life and explores within endurance limits but never advances destiny. | AI destiny answer. |
| D014 | World continues offline and may slow down. | Offline simulation answer. |
| D015 | Atranor judgment permits continuation or dissolution; role and destiny can return to the pool. | Death explanation. |
| D016 | Account owns no persistent gameplay advantage; diary remains optional. | Account progression correction. |
| D017 | Manual logout returns home; unexpected disconnect waits until return becomes necessary. | Logout distinction. |
| D018 | Optional queued stand-ins; original player reclaims the character on return. | Stand-in answer. |
| D019 | Timed multi-recipient offers resolve to the earliest accepting eligible queued player. | Queue offer explanation. |
| D020 | Spectators follow characters only, no free flight. | Explicit spectator correction. |
| D021 | No proximity voice or text chat. | Two successive communication corrections. |
| D022 | Interactions depend on relationships, roles, traits, and matching knowledge. | Interaction-depth answer. |
| D023 | Direct sharing duplicates; no memory burden or capacity. Newer received information replaces obsolete personal shards, while communal history persists. | Updated 2026-09-10; replaces the earlier lightening concept. |
| D024 | One starting community per people; they have not yet encountered each other. | Culture and social-role answer. |

No numeric balance values, technical architecture, complete trait catalogue, or role roster are implied by this record.


## Update — 2026-09-10

| ID | Decision | Basis in today's interview |
| --- | --- | --- |
| D025 | No shard weight, capacity, or oldest-first forgetting. | Answer 33 supersedes answers 31–32. |
| D026 | Shards are functional information, not general autobiography. | Answer 34. |
| D027 | Updates require performed local exchange or hub consultation; replace obsolete personal information on receipt. | Answers 35–37. |
| D028 | Relationships are neutral/positive; recognition, sympathy, trust can unlock deeper actions. | Answers 37–38. |
| D029 | Persistent Traits/Desires; situational Shards/Needs. | Answers 39–40. |
| D030 | Target 27 Desires: 9 inherited total, 9 birth-generated, 9 experiential. Exact acquisition timing open. | Answer 41. |
| D031 | Desire ↔ Trait and Need ↔ Shard have defined counterparts; own Traits and Desires may overlap. | Answers 42–43. |
| D032 | Matching extends to traits on creatures, objects, and places; start with manageable interaction variety. | Answers 44–45. |
| D033 | Persistent geography has multiple repopulatable content slots; living occupants do not morph into replacements. | Answers 46–47. |
| D034 | Nodes keep current state; collective knowledge retains historical layers and supplies newest relevant knowledge. | Answers 48–49. |
| D035 | Exchanges can generate further Needs; dependency chains have no imposed depth cap. | Answers 49–50. |
| D036 | Character UI exposes Traits/Desires/Needs/Shards; prioritize a Need, not a full graph. | Answer 51. |
| D037 | Priority shifts world signs; no map arrows, quality tiers, or added reaction subsystem. | Answers 51–53. |
| D038 | Combat locks facing/positioning and uses timely actions, injuries, and disengagement. | Answer 54. |
| D039 | Broad functional injuries first; incapacity opens context-specific survival actions. | Answers 55–56. |
| D040 | AI creatures and enemies share state-dependent interaction rules. | Answer 57. |
| D041 | Shared humanoid baseline with elemental abilities; personal qualities and state modify actions. | Answers 58–59. |

Question numbers identify the question answered by the user's reply; the following assistant question may have the next number. Question 60 remains unanswered. The 2026-09-09 snapshot is retained in the backup archive rather than left as contradictory active rules.

## Source

Project conversation: [Morkahja live RPG](https://chatgpt.com/c/6aa08555-1c60-83eb-ae68-d3555edd8d7f), retrieved 2026-09-09 and updated through 2026-09-10. The complete retrieved conversation is preserved in [the source archive](../../Morkahja-Concept-Sources.md). Examples illustrate the concept; they are not exhaustive content lists.
