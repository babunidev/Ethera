# Core Game Loop

**Status:** Established concept, updated 2026-09-10; later user corrections take precedence.

## A session

1. Inspect available characters and their current life, role, and destiny. Choose the kind of adventure to inhabit; queue if no suitable slot is available.
2. Enter the character's ongoing situation. Read their body and environmental signs, and consult people or cultural knowledge sources for leads.
3. Pursue destiny, undertake a related side quest, contribute to community life, or explore. Join others when objectives or complementary knowledge connect.
4. Discover places and objects, gain knowledge, and potentially acquire new traits through side quests.
5. Return with discoveries and useful goods. Share knowledge, contribute to collective memory, and restore well-being through purposeful community participation.
6. Leave the character to AI and eventually another player. Manual logout and unexpected disconnection have different handoff rules.

## The larger cycle

World → community → birth and traits → childhood → adulthood, role and destiny → generated world content → player adventures → persistent objects and knowledge → community history and conditions for future births.

Population determines available character slots. Successful communities can support births and therefore more simultaneous players. The simulation continues without players, potentially at a reduced speed.

See [Logout and Handoff](../06_Systems/Logout_and_Handoff.md).


## Update — 2026-09-10

Inspect Needs and relevant Shards → obtain missing or newer information through an interaction → prioritize a Need → follow world signs → perform the opportunity or negotiate an exchange → resolve it or gain a new immediate Need. Players can switch branches at any point.

Desires complement Traits in forming meaningful opportunities. Encounters, including combat, change the available action set as state changes. The long-term birth, community, and handoff cycle remains unchanged.

## Source

Project conversation: [Morkahja live RPG](https://chatgpt.com/c/6aa08555-1c60-83eb-ae68-d3555edd8d7f), retrieved 2026-09-09 and updated through 2026-09-10. The complete retrieved conversation is preserved in [the source archive](../../Morkahja-Concept-Sources.md). Examples illustrate the concept; they are not exhaustive content lists.
