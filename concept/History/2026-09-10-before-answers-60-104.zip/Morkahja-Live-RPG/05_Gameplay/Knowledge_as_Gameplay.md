# Knowledge as Gameplay

**Status:** Established concept, updated 2026-09-10. Later user decisions supersede earlier brainstorms; unresolved details are marked.

Knowledge connects current Needs to actionable opportunities. Characters carry functional Shards and can inspect the ones relevant to a chosen Need.

## Obtain and refresh information

Explore to gain knowledge. Share with nearby characters through culturally appropriate interactions, or visit the local knowledge hub. A newer shard creates an opportunity to replace an outdated personal report; it does not update by mere proximity or global synchronization.

The hub preserves history but emphasizes practical updates. It automatically selects the newest relevant known information for the current objective. If the bear is gone but the archive knows who took its claw, the next lead points toward that person.

## Turn knowledge into action

Inspect Needs → inspect relevant Shards → obtain missing information through a hub or person → prioritize a Need → follow natural or magical signs → act on the new situation.

If an exchange requires something the character lacks, a new immediate Need can extend the quest. Players may follow that chain or switch to another thread.

No knowledge-capacity management, weight system, precision tiers, or full dependency-map UI is required. Shards are functional information, not a personal diary. Permanent expertise traits such as Knows Herbs remain distinct from situational facts.

See [Knowledge Shards](../06_Systems/Knowledge_Shards.md) and [Trade and Exchange](Trade_and_Exchange.md).

## Source

[Morkahja live RPG](https://chatgpt.com/c/6aa08555-1c60-83eb-ae68-d3555edd8d7f), design discussion through 2026-09-10, interview answers 31–59. See the [preserved conversation](../../Morkahja-Concept-Sources.md) for exact wording and intermediate ideas. Examples are illustrative, not exhaustive implementation lists.
