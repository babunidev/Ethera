# Session Structure

**Status:** Established concept, updated 2026-09-10; later user corrections take precedence.

Sessions should allow a player to drop into a roleplaying experience without pressure to remain for hours or maintain one permanent personal avatar.

## Arrival

Inspect the available lives and what they are striving toward. Selection can offer a dangerous, mysterious, exploratory, or knowledge-focused experience depending on which characters are free. A player may decline an available life that does not interest them.

## In the world

Follow embodied signs, obtain knowledge, meet compatible characters, travel, explore, or contribute locally. A session can achieve a destiny objective or bring useful discoveries home without completing a major storyline.

Aimless travel eventually creates fatigue. Purposeful destiny pursuit sustains energy; community participation offers restoration. Session length is therefore influenced by engagement and activity, not a fixed round timer.

## Departure

Manual logout sends the person home. A crash or unexpected disconnect first preserves their place for reconnection, with AI eventually returning home before excessive fatigue. Other players may continue the life later.

The optional account diary would record participation without granting power or ownership.


## Update — 2026-09-10

Within the session, the character screen exposes Traits, Desires, Needs, and Shards. The player prioritizes a Need to choose which objective world signs follow and can switch branches. A quest may form a long exchange chain, but the player need not see or finish the whole dependency web in one sitting. See [Needs](../03_Characters/Needs.md).

## Source

Project conversation: [Morkahja live RPG](https://chatgpt.com/c/6aa08555-1c60-83eb-ae68-d3555edd8d7f), retrieved 2026-09-09 and updated through 2026-09-10. The complete retrieved conversation is preserved in [the source archive](../../Morkahja-Concept-Sources.md). Examples illustrate the concept; they are not exhaustive content lists.
