# Objectives and Side Quests

**Status:** Established concept, updated 2026-09-10. Later user decisions supersede earlier brainstorms; unresolved details are marked.

## Stable outcomes, changing routes

An objective describes what is needed, such as obtaining a bear claw. The bear may already be dead and the claw traded or carried elsewhere. New relevant knowledge redirects the objective toward the existing object or its holder. An item already possessed can satisfy a later requirement without repeating its acquisition.

## Needs and exchange branches

Quests and side quests create Needs. Shards provide actionable knowledge. A holder may require an exchange that meets one of their own Needs or Desires. If the seeker cannot provide it, the game generates another objective.

These dependencies may chain indefinitely. The current design does not artificially limit depth. A found match can resolve the immediate branch, allowing the player to work back through earlier exchanges.

## Personal development

Side quests support destiny and can grant permanent activity-related traits, such as Climber or Knows Herbs. Traits, Desires, role, culture, and world circumstances shape meaningful content. Overlap between different characters' objectives creates reasons to adventure together.

## Player-facing structure

The character screen shows Needs and relevant Shards, not the entire dependency web. Players prioritize a thread and may switch between side quests. Guidance follows that priority through natural or magical signs, with no map markers or compass arrows.

Selection still introduces the life and its destiny. The new character screen complements minimal in-world UI; the earlier absence of a conventional quest log must not be read as forbidding this explicit Needs screen.

Destroyed objectives, cyclic dependencies, vanished exchange partners, and final destiny completion still need recovery rules.

See [Needs](../03_Characters/Needs.md) and [Trade and Exchange](Trade_and_Exchange.md).

## Source

[Morkahja live RPG](https://chatgpt.com/c/6aa08555-1c60-83eb-ae68-d3555edd8d7f), design discussion through 2026-09-10, interview answers 31–59. See the [preserved conversation](../../Morkahja-Concept-Sources.md) for exact wording and intermediate ideas. Examples are illustrative, not exhaustive implementation lists.
