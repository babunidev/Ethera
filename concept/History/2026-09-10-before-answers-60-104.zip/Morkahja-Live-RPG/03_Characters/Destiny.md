# Destiny

**Status:** Established concept, updated 2026-09-10; later user corrections take precedence.

A destiny is a personal procedural story belonging to a persistent individual. It begins at adulthood, alongside the social role. The initial idea of destiny at birth is superseded by this timing clarification.

Destiny is shaped by traits and role and should fit the person and their culture. Connected side quests provide preparation, relevant items or knowledge, and new traits. Generation creates required world ingredients without dictating exactly how the player must obtain them.

## Player choice and purpose

Only players advance destiny. They may follow it, explore elsewhere, or participate in community life. Pursuing destiny sustains or replenishes energy. Aimless wandering eventually produces tiredness; meaningful communal participation also restores health and integrity.

Destiny matters metaphysically. Persistent loss of purpose and community connection can weaken individuality, leading toward dissolution or corruption. This is embodied rather than expressed as a conventional warning meter.

## Overlap

Destinies and side quests can share objects, locations, and creatures. One character needs a claw, another a heart, and another food from the same bear. Their lives create reasons to travel together.

Destiny completion, replacement, failure recovery, and the exact measure of “following destiny” remain open.


## Update — 2026-09-10

Desires provide another input to the direction of destiny and side quests. Objectives express Needs that may lead through existing item ownership and exchange requirements. These branches may grow indefinitely; no fixed depth cap is intended. The player selects a current Need through the character screen, changing guidance without exposing the full dependency web. This refines individual adventure scope: world placement should remain practical, but an exchange story may become very long. See [Trade and Exchange](../05_Gameplay/Trade_and_Exchange.md).

## Source

Project conversation: [Morkahja live RPG](https://chatgpt.com/c/6aa08555-1c60-83eb-ae68-d3555edd8d7f), retrieved 2026-09-09 and updated through 2026-09-10. The complete retrieved conversation is preserved in [the source archive](../../Morkahja-Concept-Sources.md). Examples illustrate the concept; they are not exhaustive content lists.
