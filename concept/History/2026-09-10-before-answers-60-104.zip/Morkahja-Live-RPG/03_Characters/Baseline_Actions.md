# Baseline Actions

**Status:** Established concept, updated 2026-09-10. Later user decisions supersede earlier brainstorms; unresolved details are marked.

## Shared embodiment

Characters have a universal set of ordinary actions. A person does not need a special walking trait to walk, a breathing role to breathe, or equipment to touch the world.

The four peoples share broadly humanoid bodies and therefore overlapping basic capabilities. The general action set is shared, with different elemental possibilities layered on top.

## Layers of available action

Shared humanoid baseline → elemental baseline → personal traits → social role → equipment → current state and injuries → actions meaningful in this situation.

Traits, roles, and equipment expand or modify the baseline. Injuries and other conditions can contract it. Basic actions remain available unless the state or situation prevents them.

The conversation's assistant examples included moving, carrying, touching, basic climbing, striking, dodging, and simple social actions. These illustrate the principle; the complete action catalogue has not been approved.

## Elemental baseline

Rokur, Verdani, Aevis, and Grimnir have different elemental abilities while retaining a familiar common foundation. This baseline embodiment can itself be represented as underlying traits, separate in purpose from the personal inherited/acquired pool. No decision says to deduct baseline traits from the 27 personal birth traits.

## Still open

The last unanswered interview question asks whether elemental abilities are available in childhood and mature over time, or whether some unlock at adulthood. Specific racial abilities and exact baseline representation are also unspecified.

See [Traits](Traits.md), [Injuries](Injuries.md), and [Combat](../05_Gameplay/Combat.md).

## Source

[Morkahja live RPG](https://chatgpt.com/c/6aa08555-1c60-83eb-ae68-d3555edd8d7f), design discussion through 2026-09-10, interview answers 31–59. See the [preserved conversation](../../Morkahja-Concept-Sources.md) for exact wording and intermediate ideas. Examples are illustrative, not exhaustive implementation lists.
