# Desires

**Status:** Established concept, updated 2026-09-10. Later user decisions supersede earlier brainstorms; unresolved details are marked.

## Persistent direction

Desires are the persistent counterpart to traits. Traits describe qualities a being has; desires describe the qualities they seek in other beings or in the world. “Desires” replaces the intermediate names Longings and persistent Needs.

## Origin and count

The target is 27 desires:

- 9 inherited from the parents, with the split between parents unspecified.
- 9 generated at birth.
- 9 emerging through growth and lived experience, especially social interactions.

The discussion also mentions role, relationships, and experience as influences. Exactly how the final nine are acquired, and whether all are complete by adulthood given that roles begin then, remains open. This is distinct from the trait formula of 9 from each parent plus 9 global traits.

## Pairing rule

Every desire has a defined trait counterpart, and each trait has a corresponding desire in the design vocabulary. A character's own trait and desire sets may overlap: someone can be Strong and desire Strong, or Funny and desire Funny. Overlap is not forbidden or rerolled.

The counterpart need not be another person. Creatures, objects, and places also carry traits, so desire can connect to a bear, treasure, a place, or an adventure-related circumstance through the appropriate trait. Desires therefore affect world interactions, side quests, and destiny as well as social life.

## Interaction variety

Ideally each specific pair has its own interaction. The initial implementation should use a manageable variety of culturally appropriate interactions and grow from there. Examples such as a bear-related revenge desire illustrate possible specificity, not a required revenge subsystem.

See [Interaction System](../06_Systems/Interaction_System.md), [Needs](Needs.md), and [Birth and Inheritance](Birth_and_Inheritance.md).

## Source

[Morkahja live RPG](https://chatgpt.com/c/6aa08555-1c60-83eb-ae68-d3555edd8d7f), design discussion through 2026-09-10, interview answers 31–59. See the [preserved conversation](../../Morkahja-Concept-Sources.md) for exact wording and intermediate ideas. Examples are illustrative, not exhaustive implementation lists.
