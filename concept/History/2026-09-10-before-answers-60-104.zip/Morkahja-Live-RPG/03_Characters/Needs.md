# Needs

**Status:** Established concept, updated 2026-09-10. Later user decisions supersede earlier brainstorms; unresolved details are marked.

## Situational requirements

Needs are temporary requirements arising from quests, side quests, exchanges, and circumstances. They are distinct from persistent Desires. Shards supply the corresponding functional knowledge.

The design pairs **Need ↔ Shard** and **Desire ↔ Trait**. Each side has a defined counterpart; this does not mean the answer is already known by the requesting character or physically nearby.

## Objectives and chains

A quest creates a Need, such as obtaining a bear claw. A relevant shard may identify a bear's old location, a later event, or the person now carrying the claw. New information can redirect the objective.

If the holder requires something in exchange and the character cannot satisfy that requirement, a new immediate Need and quest branch appear. Resolving the deeper requirement lets the player work back through earlier exchanges. There is no imposed chain-depth limit in the current design.

## Player focus

The character screen shows Traits, Desires, Needs, and relevant Shards. The player can inspect a Need, review its information, and prioritize which thread to follow. They can switch to another side quest or Need for the session.

Prioritization is a subtle internal choice. It shifts natural and magical guidance; it does not add map markers, compass arrows, a dependency-graph display, or a separate emotional reaction system.

If useful information is missing, visit the cultural knowledge hub and perform an appropriate interaction or ritual to receive a relevant shard.

See [Environmental Guidance](../07_Presentation/Environmental_Guidance.md) and [Trade and Exchange](../05_Gameplay/Trade_and_Exchange.md).

## Source

[Morkahja live RPG](https://chatgpt.com/c/6aa08555-1c60-83eb-ae68-d3555edd8d7f), design discussion through 2026-09-10, interview answers 31–59. See the [preserved conversation](../../Morkahja-Concept-Sources.md) for exact wording and intermediate ideas. Examples are illustrative, not exhaustive implementation lists.
