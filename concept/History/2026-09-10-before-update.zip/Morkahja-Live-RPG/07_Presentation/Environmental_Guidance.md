# Environmental Guidance

**Status:** Established concept, consolidated from the project conversation; later user corrections take precedence.

The world gives signs of where the character is drawn. Examples include wind leaning toward a destination, unusual light along a route, a bird rising from a bush, a gust of magic pushing through the body, or Grimnir shoulder and head stones pulling in a common direction.

Players learn direction through observing their character and surroundings. The signs should feel like a response to asking the gods for guidance rather than a UI compass.

## Complementary knowledge

Signs provide orientation; people and cultural archives supply clues. If someone knows the forest, animal, or object being sought, that knowledge can help interpret the next step.

## Shared paths

Characters may notice their signs align. Meeting a compatible person may strengthen them or draw them together, suggesting an overlapping journey.

## Choice and limits

The player can follow or ignore a sign and explore elsewhere. Fatigue eventually encourages return to community. Exact sign frequency, readability, accessibility alternatives, and behavior when a target moves remain undefined.

## Source

Project conversation: [Morkahja live RPG](https://chatgpt.com/c/6aa08555-1c60-83eb-ae68-d3555edd8d7f), retrieved 2026-09-09. The complete retrieved conversation is preserved in [the source archive](../../Morkahja-Concept-Sources.md). Examples illustrate the concept; they are not exhaustive content lists.
