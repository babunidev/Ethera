# Diegetic Interface

**Status:** Established concept, consolidated from the project conversation; later user corrections take precedence.

The interface should almost disappear during play. Characters, objects, movement, sound, gestures, and environmental events carry information usually shown in RPG panels.

## The body as interface

Well-being changes material presence. Feeling small can make a being smaller; feeling thin or transparent can make them visibly so. Good energy may produce shining, strength, muscularity, and definition. Deterioration communicates danger without an explicit warning popup or morality meter.

## Purpose and navigation

Visions, memories, instincts, conviction, and environmental signs express the character's direction. The intention is not a standard compass arrow or routine NPC quest box.

## Where text and context can exist

Character selection deliberately tells the player about a life and destiny. Queue offers provide recaps, and spectator inspection can expose lore or character details. “Minimal UI” does not mean these specified contextual screens disappear.

Player-to-player text chat is excluded. Knowledge transfer and other communication occur through contextual interactions.

## Source

Project conversation: [Morkahja live RPG](https://chatgpt.com/c/6aa08555-1c60-83eb-ae68-d3555edd8d7f), retrieved 2026-09-09. The complete retrieved conversation is preserved in [the source archive](../../Morkahja-Concept-Sources.md). Examples illustrate the concept; they are not exhaustive content lists.
