# Knowledge as Gameplay

**Status:** Established concept, consolidated from the project conversation; later user corrections take precedence.

Knowledge connects exploration, social interaction, and objectives. It is carried by particular people and cultural archives, not automatically known everywhere.

## The loop

Need information → consult someone or a local knowledge source → obtain a clue → visit a place or person → discover something → return and share it.

A report might locate a bear, point toward a forest, identify an object, or reveal who possesses it. Information can be incomplete or old, so the player follows evidence rather than a globally exact database.

## Matching people

One character carries a question or need, while another carries a compatible answer. Their internal state enables a concrete exchange. The same principle can combine with roles and relationships to generate other meaningful interactions.

## Persistence

Sharing person to person duplicates knowledge. Depositing into collective memory can remove the shard from the individual and lighten their burden. The exact burden model remains unanswered.

Learned qualities such as Knows Herbs can also be permanent traits. How broad expertise differs technically from individual factual shards remains open.

## Source

Project conversation: [Morkahja live RPG](https://chatgpt.com/c/6aa08555-1c60-83eb-ae68-d3555edd8d7f), retrieved 2026-09-09. The complete retrieved conversation is preserved in [the source archive](../../Morkahja-Concept-Sources.md). Examples illustrate the concept; they are not exhaustive content lists.
