# Exploration

**Status:** Established concept, consolidated from the project conversation; later user corrections take precedence.

Exploration is a central contribution to communal life. A player can follow destiny signs or investigate something else: a creature, plant, cave, unusual object, glittering feature in a tree, or unfamiliar route.

What is possible depends on traits and roles. A climber may reach something in a tree; a hunter may see and interpret prey tracks. Characters can perceive different opportunities in the same place.

## Knowledge returns home

Seeing a bear creates knowledge of the sighting. Finding an object creates information about its existence and potentially who now carries it. Returning to the village allows discoveries to become communal resources even when no destiny objective was completed.

## Direction and endurance

Wind, light, birds, magic, or the character's own elemental body can indicate a direction. Cultural knowledge sources provide clues based on discoveries already shared.

Aimless wandering gradually tires a character. Returning to purposeful social life restores them. Following destiny can sustain or replenish energy. AI also explores, but respects endurance and does not advance destiny.

## Source

Project conversation: [Morkahja live RPG](https://chatgpt.com/c/6aa08555-1c60-83eb-ae68-d3555edd8d7f), retrieved 2026-09-09. The complete retrieved conversation is preserved in [the source archive](../../Morkahja-Concept-Sources.md). Examples illustrate the concept; they are not exhaustive content lists.
