# Objectives and Side Quests

**Status:** Established concept, consolidated from the project conversation; later user corrections take precedence.

## Goal-oriented objectives

An objective expresses the needed outcome, not a rigid action script. “Obtain a bear claw” remains meaningful if another person already killed the bear and the claw was sold, carried away, or lost. The route changes to pursue the existing object.

Items can be obtained before the objective becomes relevant. Having suitable evidence or the required item already should allow immediate satisfaction rather than demanding repetition after quest acceptance.

## Side quests

Side quests support destiny with relevant experiences, items, and knowledge. They can award a permanent trait arising from the activity: climbing leads to Climber, studying plants to Knows Herbs, and learning a language to corresponding knowledge.

Roles influence some quests and rewards so the character develops coherently. Objectives can overlap across characters, creating reasons to adventure together.

## Presentation

Purpose comes through the character: visions, knowledge, internal direction, and environmental signs. The selection screen gives story context. Routine NPC quest-giver dialogue boxes and a conventional quest log are not the intended foundation.

Destroyed required objects, impossible objectives, final destiny completion, and procedural recovery rules remain open.

## Source

Project conversation: [Morkahja live RPG](https://chatgpt.com/c/6aa08555-1c60-83eb-ae68-d3555edd8d7f), retrieved 2026-09-09. The complete retrieved conversation is preserved in [the source archive](../../Morkahja-Concept-Sources.md). Examples illustrate the concept; they are not exhaustive content lists.
