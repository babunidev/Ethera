# Objects and Persistence

**Status:** Established concept, consolidated from the project conversation; later user corrections take precedence.

Objects exist in the world independently of quest acceptance. A bear has its claw before someone needs it. Loot is not withheld simply because a relevant quest is inactive.

## Persistent history

If a bear dies, its existing claw may be taken, sold, lost, or carried elsewhere. A later seeker follows that object's history rather than receiving a replacement bear. If the seeker already possesses a suitable claw, the requirement can already be satisfied.

Completing an objective does not automatically delete the object. It remains available for later uses and stories. Consumption and physical change are exceptions: food can be eaten, and materials can be used or transformed.

## Community knowledge

A character can keep an object while reporting that they have it. Others can then discover who possesses what they need. This separates the physical object from knowledge about it.

## World continuity

Locations become available for new content when their prior use genuinely ends. Existing objects and remains should not disappear merely because a quest completed.

Ownership permissions, exact object identity versus interchangeable examples, decomposition, storage, and destruction recovery remain implementation questions.

## Source

Project conversation: [Morkahja live RPG](https://chatgpt.com/c/6aa08555-1c60-83eb-ae68-d3555edd8d7f), retrieved 2026-09-09. The complete retrieved conversation is preserved in [the source archive](../../Morkahja-Concept-Sources.md). Examples illustrate the concept; they are not exhaustive content lists.
