# Social Gameplay

**Status:** Established concept, consolidated from the project conversation; later user corrections take precedence.

Roleplay has practical meaning. Shared work, team activity, music, dance, celebration, and communal moments can make people healthier, more resilient, and more grounded in their individuality.

The intended audience is adult, and adult sexuality and intimate relationships were included as part of social life. Their presentation and mechanics are not specified. Childhood is a separate playable phase, and its interaction rules still require definition.

## Contextual interaction

Interactions arise from the actual relationship between two people, their roles, traits, and matching pieces of knowledge. The design should ask what meaningful exchange exists here rather than offer only a shallow universal gesture list.

If one character needs a bear's location and another knows it, a knowledge-sharing action becomes possible. Culture determines how the exchange appears. Other role combinations can unlock special actions for one or both participants.

There is no free player text or proximity voice chat. Signals, contextual actions, movement, and culturally appropriate exchanges carry communication.

## Source

Project conversation: [Morkahja live RPG](https://chatgpt.com/c/6aa08555-1c60-83eb-ae68-d3555edd8d7f), retrieved 2026-09-09. The complete retrieved conversation is preserved in [the source archive](../../Morkahja-Concept-Sources.md). Examples illustrate the concept; they are not exhaustive content lists.
