# Aevis

**Status:** Established lore from the supplied world introduction.

## The Windweavers
Beings of air and aether, the Aevis dwell beneath the mountains in Celesterra and other hidden subterranean cities. Uncontrolled winds can unravel their bodies, so their sheltered homeland is essential to survival.

## Homeland and settlements
Luminous crystals form artificial skies above slender towers. Carefully guided currents carry movement and life through enormous caverns.

## Community and everyday life
Society values learning, mentorship, and disciplined magical practice. Daily life centers on scholarship, architecture, crystal craftsmanship, and maintaining the atmosphere that holds their world together.

## Knowledge traditions from the RPG conversation

Crystal archives, harmonic chambers, and Resonance Archives preserve knowledge through resonance and support communal retrieval.

## Place in this game

The ancient RPG begins with a separate community for each people, before they have met. The developed settlements described above come from the broader world introduction; their precise early forms remain open. Roles are culture-specific callings assigned at adulthood from traits. Their exact roster has not been chosen.

All peoples participate in the shared character system: 27 latent birth traits, playable childhood, adult roles and destinies, temporary player inhabitation, and continuing AI life. How reproduction and dissolution appear for each elemental body still needs detailed adaptation.

See [Cultural Knowledge Systems](../04_Community/Cultural_Knowledge_Systems.md), [Birth and Inheritance](../03_Characters/Birth_and_Inheritance.md), and [Ancient Morkahja](../01_World/Ancient_Morkahja.md).

## Sources

*Morkahja - World and Peoples.pdf*, supplied world introduction; and [Morkahja live RPG](https://chatgpt.com/c/6aa08555-1c60-83eb-ae68-d3555edd8d7f), including the user-provided worldbuilding knowledge extract.
