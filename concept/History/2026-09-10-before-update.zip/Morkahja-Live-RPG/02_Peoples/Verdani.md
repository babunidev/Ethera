# Verdani

**Status:** Established lore from the supplied world introduction.

## The Bloomkin
Graceful, horned beings formed from living water, the Verdani inhabit Evergrove, a desert realm sustained by an immense underground network of roots and waterways.

## Homeland and settlements
Settlements bloom around oases. Canals wind between gardens and curved sandstone homes.

## Community and everyday life
Healers, waterkeepers, and gardeners sustain communities through water magic and careful stewardship. Life is expressive and communal, with music, shared meals, and festivals. Ancestral memories are preserved in enchanted pools.

## Knowledge traditions from the RPG conversation

Memory Pools tended by Memorykeepers preserve communal experiences and provide a foundation for sharing sightings and laying down knowledge.

## Place in this game

The ancient RPG begins with a separate community for each people, before they have met. The developed settlements described above come from the broader world introduction; their precise early forms remain open. Roles are culture-specific callings assigned at adulthood from traits. Their exact roster has not been chosen.

All peoples participate in the shared character system: 27 latent birth traits, playable childhood, adult roles and destinies, temporary player inhabitation, and continuing AI life. How reproduction and dissolution appear for each elemental body still needs detailed adaptation.

See [Cultural Knowledge Systems](../04_Community/Cultural_Knowledge_Systems.md), [Birth and Inheritance](../03_Characters/Birth_and_Inheritance.md), and [Ancient Morkahja](../01_World/Ancient_Morkahja.md).

## Sources

*Morkahja - World and Peoples.pdf*, supplied world introduction; and [Morkahja live RPG](https://chatgpt.com/c/6aa08555-1c60-83eb-ae68-d3555edd8d7f), including the user-provided worldbuilding knowledge extract.
