# Ideas

**Status:** Established concept, consolidated from the project conversation; later user corrections take precedence.

## Retained optional ideas

- A very lightweight account diary or timeline of notable participation. It must not provide permanent gameplay power or ownership.
- Nine initially active traits in childhood, revealed randomly from the latent pool. The growth rule is established; the starting number was phrased tentatively.
- In-world lore inspection while queued, including buildings and character information. Detailed visibility rules remain open under follow-only spectating.
- An early notion of notifying players when too few people are active and the village suffers. This was not finalized and should be considered alongside competent offline AI and low-pressure sessions.

## Illustrative content from the conversation

- A shared bear adventure with different characters seeking claw, heart, or meat.
- A bear site later hosting a flower or lost family item after the old contents are gone.
- A cave gaining a new occupant after its earlier purpose ends.
- Finding something glittering in a tree that a character with climbing ability can investigate.
- A distant mountain destiny whose route contains intermediate encounters.
- Cultural signs such as a rising bird, directed light, or Grimnir stones pulling toward a destination.

These examples explain systems; they do not establish a mandatory starter quest sequence.

## Superseded explorations

Proximity voice chat, free-flight spectating, personal account progression, and destiny/social-role activation at birth were replaced by later decisions. Do not implement the early versions merely because they remain in the source transcript.

## Source

Project conversation: [Morkahja live RPG](https://chatgpt.com/c/6aa08555-1c60-83eb-ae68-d3555edd8d7f), retrieved 2026-09-09. The complete retrieved conversation is preserved in [the source archive](../../Morkahja-Concept-Sources.md). Examples illustrate the concept; they are not exhaustive content lists.
