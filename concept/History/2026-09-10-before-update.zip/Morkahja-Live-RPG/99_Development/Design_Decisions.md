# Design Decisions

**Status:** Established concept, consolidated from the project conversation; later user corrections take precedence.

Later explicit user statements override earlier brainstorms and assistant summaries.

| ID | Current decision | Conversation basis |
| --- | --- | --- |
| D001 | Persistent world characters are temporarily inhabited; players do not own avatars. | Opening concept. |
| D002 | Shared multiplayer RPG with autonomous settlements; no building management by players. | Explicit settlement-control correction. |
| D003 | Population growth adds available character slots. | Community and reproduction discussion. |
| D004 | Objects exist before objectives and remain afterward unless physically used or changed. | Bear claw and earlier-loot examples. |
| D005 | Objectives follow goals and existing objects, not mandatory repeated kills. | Dynamic bear objective example. |
| D006 | Reuse vacant nodes and add new content with every destiny. | Expansion and repopulation clarification. |
| D007 | Traits are binary and never routinely lost. | Interview answers on trait ranks and decay. |
| D008 | Birth pool is 27 traits: 9 + 9 parental and 9 global, without category balancing. | Trait-count and random-draw answers. |
| D009 | Childhood is playable; all birth traits active by adulthood. | Growth explanation. |
| D010 | Role and destiny begin at adulthood. | Explicit later timing corrections. |
| D011 | Roles grant abilities and unique interactions; exact lists are culture-specific and deferred. | Hunter tracking and culture discussions. |
| D012 | Side quests can add relevant permanent traits. | Climber and herb-learning examples. |
| D013 | AI maintains life and explores within endurance limits but never advances destiny. | AI destiny answer. |
| D014 | World continues offline and may slow down. | Offline simulation answer. |
| D015 | Atranor judgment permits continuation or dissolution; role and destiny can return to the pool. | Death explanation. |
| D016 | Account owns no persistent gameplay advantage; diary remains optional. | Account progression correction. |
| D017 | Manual logout returns home; unexpected disconnect waits until return becomes necessary. | Logout distinction. |
| D018 | Optional queued stand-ins; original player reclaims the character on return. | Stand-in answer. |
| D019 | Timed multi-recipient offers resolve to the earliest accepting eligible queued player. | Queue offer explanation. |
| D020 | Spectators follow characters only, no free flight. | Explicit spectator correction. |
| D021 | No proximity voice or text chat. | Two successive communication corrections. |
| D022 | Interactions depend on relationships, roles, traits, and matching knowledge. | Interaction-depth answer. |
| D023 | Direct shard sharing duplicates; communal deposit permits relinquishing and lightening. | Final answered shard question. |
| D024 | One starting community per people; they have not yet encountered each other. | Culture and social-role answer. |

No numeric balance values, technical architecture, complete trait catalogue, or role roster are implied by this record.

## Source

Project conversation: [Morkahja live RPG](https://chatgpt.com/c/6aa08555-1c60-83eb-ae68-d3555edd8d7f), retrieved 2026-09-09. The complete retrieved conversation is preserved in [the source archive](../../Morkahja-Concept-Sources.md). Examples illustrate the concept; they are not exhaustive content lists.
