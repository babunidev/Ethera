# Open Questions

**Status:** Established concept, consolidated from the project conversation; later user corrections take precedence.

## Questions still unanswered

1. Does every shard have an individual burden, or does burden simply grow with shard count? This was the final unanswered interview question.
2. Are shards distinct from traits internally? How are questions, answers, facts, and broad expertise represented?
3. How do duplicate trait draws work, and must the birth pool contain 27 distinct qualities?
4. Which parental traits can be inherited? How do later childhood gains enter adult role generation?
5. What are the exact childhood stages, timing, and initial active-trait count? Nine was suggested.
6. What are each culture's ancient-era social roles and unique interactions?
7. Is required destiny content prepared at birth or generated at adulthood, when role and destiny begin?
8. How do completed, failed, or impossible destinies behave? What if a required object is consumed or destroyed?
9. What determines fatigue, purpose, godly essence, corruption, and divine judgment? How do their outcome paths connect?
10. How does magic's arrival fit the already elemental peoples and the larger world's chronology?
11. Which developed cultural institutions and homeland features already exist in this primitive era?
12. What are the offline simulation rate, population rules, and practical server scale?
13. What are queue timers, reservation limits, return priority details, and stand-in protections?
14. What can spectators inspect without exposing undiscovered information?
15. How do property, conflicting player actions, and relationship change work?
16. What are the final camera controls, combat mechanics, platform, and production scope?
17. How are adult social content and life-stage interaction boundaries implemented?
18. Is a purely reflective account diary worth including?

## Already decided — do not reopen as missing information

Multiplayer, temporary inhabitation, autonomous village development, 27 birth traits, binary permanent traits, adulthood role/destiny timing, player-only destiny advancement, no voice/text chat, follow-only spectators, and person-to-person shard duplication are established.

These documents preserve the concept to date. They do not claim that every implementation parameter has been designed.

## Source

Project conversation: [Morkahja live RPG](https://chatgpt.com/c/6aa08555-1c60-83eb-ae68-d3555edd8d7f), retrieved 2026-09-09. The complete retrieved conversation is preserved in [the source archive](../../Morkahja-Concept-Sources.md). Examples illustrate the concept; they are not exhaustive content lists.
