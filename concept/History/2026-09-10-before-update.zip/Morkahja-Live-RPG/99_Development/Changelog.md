# Changelog

**Status:** Established concept, consolidated from the project conversation; later user corrections take precedence.

## 2026-09-09 — complete concept consolidation

- Created the exact requested structure: README plus 50 topic documents across nine folders.
- Retrieved the complete available “Morkahja live RPG” conversation through all history pages and consulted “Create Morkahja Files” for the intended documentation structure.
- Replaced the initial PDF-only provisional drafts with the actual established game concept.
- Preserved later corrections over earlier ideas, including adulthood timing, no voice/text chat, and follow-only spectators.
- Preserved the supplied PDF's world and peoples lore without changing synced source files.
- Kept broader-world city descriptions distinct from unresolved ancient-era adaptations.
- Saved the complete retrieved design conversation separately as Morkahja-Concept-Sources.md so original wording and assistant interpretations remain reviewable.
- Packaged the topic folder and source transcript together in a ZIP.

## Source scope

The main concept source is the project conversation “Morkahja live RPG.” “Create Morkahja Files” supplies the organizational intent. The local synced source directory contains “Morkahja - World and Peoples.pdf.”

The RPG conversation also includes a user-pasted knowledge-system extract citing the separate worldbuilding project's race notes. This archive preserves that contributed material, without claiming to export the entire separate worldbuilding project.

Earlier assistant-generated interpretations are retained in the source transcript, but only supported design choices are consolidated into the topic documents. Open questions remain explicit.

## Source

Project conversation: [Morkahja live RPG](https://chatgpt.com/c/6aa08555-1c60-83eb-ae68-d3555edd8d7f), retrieved 2026-09-09. The complete retrieved conversation is preserved in [the source archive](../../Morkahja-Concept-Sources.md). Examples illustrate the concept; they are not exhaustive content lists.
