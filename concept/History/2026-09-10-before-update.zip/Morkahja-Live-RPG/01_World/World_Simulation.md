# World Simulation

**Status:** Established concept, consolidated from the project conversation; later user corrections take precedence.

Morkahja persists when nobody is online. AI residents perform their roles and maintain the settlement rather than freezing between sessions. The simulation can slow down in the absence of players, but should still progress.

## What the simulation sustains

Community needs, homes, food, clean water, warmth, health, safety, social life, partnership, reproduction, and the lives of existing residents. Births add new people and playable slots. Objects and knowledge remain connected to their histories.

AI behaves sensibly and communally, maintaining ordinary life and exploring within endurance limits. It does not pursue personal destiny. Players introduce deliberate adventure, risk, and unusual choices through individual characters.

## Authority

Players do not decide village layout or direct its development. Construction and organization emerge from the society itself. Character actions affect communal conditions without granting settlement-level control.

## Open implementation

Tick rates, offline slowdown, population limits, ecological detail, and how growth maps to technical server capacity remain undesigned. Population-based slots are a game rule, not a claim that hosting capacity has no technical limits.

## Source

Project conversation: [Morkahja live RPG](https://chatgpt.com/c/6aa08555-1c60-83eb-ae68-d3555edd8d7f), retrieved 2026-09-09. The complete retrieved conversation is preserved in [the source archive](../../Morkahja-Concept-Sources.md). Examples illustrate the concept; they are not exhaustive content lists.
