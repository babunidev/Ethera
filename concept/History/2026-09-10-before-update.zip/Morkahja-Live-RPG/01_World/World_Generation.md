# World Generation

**Status:** Established concept, consolidated from the project conversation; later user corrections take precedence.

## Stories create world content

Characters' traits, roles, destinies, and side quests bring the required places, creatures, items, and circumstances into the world. A destiny requiring a bear creates an appropriate bear and location; another may require a tree, cave, trail, or important object. Generation establishes the ingredients, while players determine how events unfold.

Later decisions place social roles and destiny at adulthood. The initial birth-generated-content idea therefore becomes a lifetime pipeline: birth defines traits, childhood reveals them, and adulthood establishes role and destiny. Whether content is secretly prepared earlier or generated at adulthood is still open.

## Reuse and expansion together

Each destiny should expand the world with new content. It must also reuse suitable existing nodes so older areas stay relevant and travel does not become endlessly longer.

A bear site becomes vacant only after the bear and relevant remains have gone. A flower may later grow there, someone may lose a family object there, or a cave may acquire a new occupant. A place persists while its current purpose changes. These are examples of repopulation, not timer-based identical respawns.

## Journey scale

Adventures should remain broadly manageable in size. An early destiny may already point to distant mountains, with routes and intermediate encounters making up the journey. New content does not have to begin beside the village.

Rules for node vacancy, conflicting destinies, map boundaries, and placement validation remain open.

## Source

Project conversation: [Morkahja live RPG](https://chatgpt.com/c/6aa08555-1c60-83eb-ae68-d3555edd8d7f), retrieved 2026-09-09. The complete retrieved conversation is preserved in [the source archive](../../Morkahja-Concept-Sources.md). Examples illustrate the concept; they are not exhaustive content lists.
