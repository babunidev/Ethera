# Relationships

**Status:** Established concept, consolidated from the project conversation; later user corrections take precedence.

Relationships provide context for meaningful interactions. What two people can do together depends on their relationship, social roles, traits, and matching knowledge or needs.

## Community continuity

Partnership and reproduction support new generations. A new being may enter the social network of their parents, including family and friends. The conversation considered this network but did not commit to a detailed relationship simulation.

## Play

Shared work, music, dance, celebration, and adult intimacy can strengthen communal life. Roles can unlock interactions unavailable to other pairs. Knowledge also connects people: a question in one character and an answer in another create a specific exchange opportunity.

## Boundaries of the current design

No numeric affection, reputation, loyalty, or relationship-decay system is specified. The permanent-trait rule means a trait such as Loved is not routinely removed through maintenance failure. How such traits coexist with changing relationships remains an open design detail.

## Source

Project conversation: [Morkahja live RPG](https://chatgpt.com/c/6aa08555-1c60-83eb-ae68-d3555edd8d7f), retrieved 2026-09-09. The complete retrieved conversation is preserved in [the source archive](../../Morkahja-Concept-Sources.md). Examples illustrate the concept; they are not exhaustive content lists.
