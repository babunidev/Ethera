# Cultural Knowledge Systems

**Status:** Established concept, consolidated from the project conversation; later user corrections take precedence.

The user brought worldbuilding reference material into the RPG conversation to ground local knowledge systems in existing cultures.

| People | Lore foundation | Gameplay use |
| --- | --- | --- |
| Verdani | Memory Pools tended by Memorykeepers; communal experiences in enchanted water. | Consult contributed memories for places, sightings, or objects. |
| Rokur | Clan-Hearths as archives and educational centers; Hearthkeepers, storytellers, oral teaching. | Retrieve local reports or connect with someone who knows more. |
| Aevis | Crystal archives, harmonic chambers, Resonance Archives, communal repositories. | Consult preserved observations and descriptions through resonance. |
| Grimnir | Memory stones, architectural records, Memory-Keepers, and traveling Skykeepers. | Trace history and objects through stones, craft lineages, and keepers. |

## Shared function

These traditions collect current knowledge alongside history. A response may indicate something available in stores, someone who owns it, a known place, a recent sighting, or a person with further information. Those answer types are illustrative, not a finalized menu.

Knowledge is local and fallible. Larger archives and traveling keepers can broaden what is available, but reports can age or be incomplete.

## Ancient-era treatment

The precise early forms of these institutions need reconciliation with isolated primitive villages. Later removal of voice and text chat means consultation is conveyed through cultural and contextual interactions, not free-form player conversation.

## Source

Project conversation: [Morkahja live RPG](https://chatgpt.com/c/6aa08555-1c60-83eb-ae68-d3555edd8d7f), retrieved 2026-09-09. The complete retrieved conversation is preserved in [the source archive](../../Morkahja-Concept-Sources.md). Examples illustrate the concept; they are not exhaustive content lists.
