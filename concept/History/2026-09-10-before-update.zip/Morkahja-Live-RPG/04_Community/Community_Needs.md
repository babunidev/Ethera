# Community Needs

**Status:** Established concept, consolidated from the project conversation; later user corrections take precedence.

The village needs more than quest completion. Its ongoing tasks include food, clean water, warmth at night, homes, health, safety, partners and reproduction, meaningful roles, and opportunities for enjoyment and connection.

Material conditions support social events: a community needs sufficient food, water, warmth, and security to gather comfortably. Celebration and shared activity in turn help sustain its members.

## Player contribution

A hunter brings food, an explorer brings observations, and a character may contribute an object or information about possessing it. Participation matters even when a session does not advance destiny.

General village tasks coexist with personal destiny and side quests. Their benefit belongs to the community rather than the player account.

## Elemental interpretation

The source lore grounds different environmental dependencies: Rokur bodily balance in cold surroundings, Verdani water stewardship, Aevis maintained atmosphere, and Grimnir craft and navigation. How each need operates in primitive settlements remains to be designed; no resource rates or numeric meters have been established.

## Source

Project conversation: [Morkahja live RPG](https://chatgpt.com/c/6aa08555-1c60-83eb-ae68-d3555edd8d7f), retrieved 2026-09-09. The complete retrieved conversation is preserved in [the source archive](../../Morkahja-Concept-Sources.md). Examples illustrate the concept; they are not exhaustive content lists.
