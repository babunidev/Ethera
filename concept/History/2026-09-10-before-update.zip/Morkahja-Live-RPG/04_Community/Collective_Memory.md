# Collective Memory

**Status:** Established concept, consolidated from the project conversation; later user corrections take precedence.

Collective memory is a cultural archive of both history and useful local knowledge. It grows from inhabitants' discoveries and contributions instead of providing omniscient information about the world.

Residents contribute sightings, routes, materials, unusual objects, and information about who possesses something. A sighting can become outdated; descriptions may be incomplete. A community knows what its people have learned and shared.

## Sharing and laying down knowledge

Person-to-person sharing duplicates a shard. The source person retains knowledge while another gains a copy.

The collective archive is the special case: an individual can deposit a shard and relinquish it personally, lightening themselves while the communal memory preserves it.

## Cultural expression

Memory pools, hearth traditions, resonance archives, memory stones, and keepers embody this function differently. These are not a universal global database.

Shard weight, capacity, retention, retrieval costs, and whether depositing always relinquishes or can optionally copy are not fully specified beyond the ability to offload personal shards.

## Source

Project conversation: [Morkahja live RPG](https://chatgpt.com/c/6aa08555-1c60-83eb-ae68-d3555edd8d7f), retrieved 2026-09-09. The complete retrieved conversation is preserved in [the source archive](../../Morkahja-Concept-Sources.md). Examples illustrate the concept; they are not exhaustive content lists.
