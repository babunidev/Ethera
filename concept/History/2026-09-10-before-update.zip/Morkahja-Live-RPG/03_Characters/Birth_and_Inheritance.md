# Birth and Inheritance

**Status:** Established concept, consolidated from the project conversation; later user corrections take precedence.

## Birth and population

Reproduction creates new persistent people, which increases the number of characters available for player inhabitation. A successful community supports population growth. Birth is part of the simulation rather than player avatar creation.

## The 27-trait draw

1. Randomly draw 9 traits from parent A.
2. Randomly draw 9 traits from parent B.
3. Randomly draw 9 traits from the full trait pool across all types.

There is no guaranteed category spread or balancing into a predetermined role. Draw first, then interpret the person. The traits influence appearance and personality, and the adult role follows the resulting aptitudes.

The concept likens this to shuffling and drawing cards. Duplicate handling between parents and the global pool, eligibility of learned parental traits, and incompatible combinations are not yet specified.

## Life-stage timing

All 27 traits belong to the newborn latently. Only some are active during childhood, with all active by adulthood. Roles and destiny begin at adulthood under the later clarification.

Family and parental friends may carry over as a social starting network. Biological or elemental reproduction details for each people have not been established for this RPG in the retrieved conversation.

## Source

Project conversation: [Morkahja live RPG](https://chatgpt.com/c/6aa08555-1c60-83eb-ae68-d3555edd8d7f), retrieved 2026-09-09. The complete retrieved conversation is preserved in [the source archive](../../Morkahja-Concept-Sources.md). Examples illustrate the concept; they are not exhaustive content lists.
