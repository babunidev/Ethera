# AI Control

**Status:** Established concept, consolidated from the project conversation; later user corrections take precedence.

Uninhabited characters remain active people. AI fulfills their community role at a basic competent level, participates in society, and can explore and gather knowledge.

## Limits

AI does not advance personal destiny. Exploration is limited by tiredness and the ability to return home. Meaningful community participation replenishes a character and keeps them healthy without requiring a player to advance destiny constantly.

The offline society acts sensibly and maintains itself rather than deliberately sabotaging or exploiting the world. Simulation can slow when no players are present.

## Handoff

Manual logout sends the character home under AI. Unexpected disconnection first leaves them waiting in place, until they must depart to get home before excessive fatigue. An opted-in stand-in may temporarily take control when there is a queue.

See [NPC AI](../06_Systems/NPC_AI.md) and [Logout and Handoff](../06_Systems/Logout_and_Handoff.md).

## Source

Project conversation: [Morkahja live RPG](https://chatgpt.com/c/6aa08555-1c60-83eb-ae68-d3555edd8d7f), retrieved 2026-09-09. The complete retrieved conversation is preserved in [the source archive](../../Morkahja-Concept-Sources.md). Examples illustrate the concept; they are not exhaustive content lists.
