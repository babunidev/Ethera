# Childhood

**Status:** Established concept, consolidated from the project conversation; later user corrections take precedence.

Childhood is playable. Children physically grow over time, initially within their community, and remain more fragile and less capable than adults.

## Gradual expression

All 27 birth traits are latent from birth. The suggested starting expression is 9 randomly selected traits from that pool, followed by further unlocks at aging steps until all 27 are active at adulthood. The initial nine is a proposed number in the conversation; exact stages and timing are not fixed.

A child with Strong remains strong relative to a child, not equivalent to an adult with that trait. Aging reveals latent qualities while bodily capability remains age-dependent.

## Play

Children explore, discover, learn, help with community tasks, and engage in free play. They can acquire additional traits through experience before adulthood.

Children have no destiny and no assigned social role. Both begin at adulthood. This makes childhood a less directed phase of possibility, rather than an adult campaign with reduced numbers.

Growth duration, available tasks, and age-specific interaction boundaries still need specification.

## Source

Project conversation: [Morkahja live RPG](https://chatgpt.com/c/6aa08555-1c60-83eb-ae68-d3555edd8d7f), retrieved 2026-09-09. The complete retrieved conversation is preserved in [the source archive](../../Morkahja-Concept-Sources.md). Examples illustrate the concept; they are not exhaustive content lists.
