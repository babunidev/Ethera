# Traits

**Status:** Established concept, consolidated from the project conversation; later user corrections take precedence.

## Rules

Traits are discrete qualities: a character either has one or does not. There are no trait ranks in the current design. Progress adds diversity and new possibilities rather than increasingly narrow vertical specialization.

Once acquired, a trait remains. No forgetting, confidence decay, or loss of competence is imposed as routine upkeep. Temporary fatigue and changes in visible well-being do not delete underlying traits.

## Breadth

The four broad families are Combat, Trickery, Aid, and Social. Qualities can be physical, practical, social, magical, or knowledge-related. Examples from the discussion include Strong, Funny, Loved, Fast, Good Climber, Good Speaker, Green Thumb, Knows Herbs, Knows Language, Knows Element, and Knows Magic. This is not a finalized trait catalogue.

## Acquisition

A newborn has 27 latent traits: 9 drawn from each parent and 9 from the complete pool. Childhood activates them gradually. Side quests can add further traits based on their activities, such as Climber from climbing or Knows Herbs from studying plants. The 27 count is the birth pool, not a lifetime cap.

## Knowledge distinction

Later discussion introduces shards for facts such as a bear sighting and needs that match those facts. Shards can be duplicated or deposited and relinquished; permanent traits are not lost. The exact shared data model and terminology remain open.

## Source

Project conversation: [Morkahja live RPG](https://chatgpt.com/c/6aa08555-1c60-83eb-ae68-d3555edd8d7f), retrieved 2026-09-09. The complete retrieved conversation is preserved in [the source archive](../../Morkahja-Concept-Sources.md). Examples illustrate the concept; they are not exhaustive content lists.
