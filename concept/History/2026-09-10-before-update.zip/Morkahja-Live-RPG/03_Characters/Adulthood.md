# Adulthood

**Status:** Established concept, consolidated from the project conversation; later user corrections take precedence.

Adulthood is the point when all 27 birth traits are active, the social role is assigned, and personal destiny begins.

## Derivation

The game interprets the character's qualities in their culture. Aptitudes produce a calling with distinct abilities and interactions. That role, the traits, culture, settlement, and world situation inform destiny and associated side quests.

Side quests can award qualities that further support the calling. A hunter may gain related knowledge and abilities without becoming “Hunter Level 12.” Development remains horizontal and cumulative.

## Two kinds of purpose

An adult participates in community life through their role and may pursue destiny while a player controls them. Both personal purpose and communal participation sustain individual integrity. AI can maintain the communal side but cannot advance personal destiny.

Adult aging, lifespan, role reassignment after later trait gains, and whether learned childhood traits alter the initial role calculation remain to be specified precisely.

## Source

Project conversation: [Morkahja live RPG](https://chatgpt.com/c/6aa08555-1c60-83eb-ae68-d3555edd8d7f), retrieved 2026-09-09. The complete retrieved conversation is preserved in [the source archive](../../Morkahja-Concept-Sources.md). Examples illustrate the concept; they are not exhaustive content lists.
