# Character System

**Status:** Established concept, consolidated from the project conversation; later user corrections take precedence.

## World-owned lives

Every playable character already belongs to the persistent world and community. They alternate between AI and player control. A later player continues that person's actual history, rather than resetting an avatar.

## Identity

Traits provide the building blocks for abilities, personality, appearance, and eventually social role and destiny. Strength should visibly affect form; the person should look and act like the qualities that compose them. Family and social connections may provide a starting network, although relationship detail is not settled.

Characters also carry current knowledge, objects, life stage, ongoing objectives, and embodied well-being. Knowledge shards provide situational information and should not be confused with permanently acquired traits.

## Life course

Birth creates 27 latent traits. Playable childhood gradually reveals them and permits additional learning. At adulthood all birth traits are active; social role and destiny begin. Players advance destiny, while AI maintains ordinary life. Exhaustion of godly essence leads to Atranor and possible continuation or dissolution.

See [Traits](Traits.md), [Childhood](Childhood.md), and [Adulthood](Adulthood.md).

## Source

Project conversation: [Morkahja live RPG](https://chatgpt.com/c/6aa08555-1c60-83eb-ae68-d3555edd8d7f), retrieved 2026-09-09. The complete retrieved conversation is preserved in [the source archive](../../Morkahja-Concept-Sources.md). Examples illustrate the concept; they are not exhaustive content lists.
