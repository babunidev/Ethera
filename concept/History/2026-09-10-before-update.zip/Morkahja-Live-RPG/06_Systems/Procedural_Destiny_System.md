# Procedural Destiny System

**Status:** Established concept, consolidated from the project conversation; later user corrections take precedence.

## Generation pipeline

1. Draw 27 birth traits without category balancing.
2. Reveal the birth pool through childhood; permit additional experiential traits.
3. At adulthood interpret the person in their culture and assign a social role.
4. Derive a fitting destiny and supporting side quests.
5. Supply required creatures, places, objects, paths, and circumstances through existing nodes and new world content.
6. Connect compatible objectives across characters.
7. Let player actions change the route while preserving the goal and existing world state.

The system creates conditions for a story; it does not preordain how each objective is achieved. A moved object changes the search rather than resetting the encounter.

## Content lifetime

Every destiny contributes new content while repopulating suitable vacant nodes. Required objects remain after completion unless physically consumed or transformed. Dissolved individuals' roles and destinies return to the generative pool.

## Constraints still needed

Exact generation timing versus adulthood activation, dependency validation, impossible goals, uniqueness, competing claims, placement costs, and complete-destiny behavior remain open. This is a design pipeline, not a chosen AI or procedural implementation.

## Source

Project conversation: [Morkahja live RPG](https://chatgpt.com/c/6aa08555-1c60-83eb-ae68-d3555edd8d7f), retrieved 2026-09-09. The complete retrieved conversation is preserved in [the source archive](../../Morkahja-Concept-Sources.md). Examples illustrate the concept; they are not exhaustive content lists.
