# Memory Wells

**Status:** Established concept, consolidated from the project conversation; later user corrections take precedence.

Memory wells are the collective-memory destination named in the discussion of depositing shards. A person can relinquish knowledge there, preserving it communally while lightening their own burden.

## Functions

The communal system both supplies useful knowledge and receives new discoveries. Its contents reflect what the community has learned and shared. It can identify leads, recent sightings, known locations, objects, or people who know more.

## Cultural embodiment

Verdani Memory Pools are the most literal watery foundation. Rokur hearth traditions, Aevis resonance archives, and Grimnir stones and keepers serve comparable cultural knowledge functions. The design has not declared that all peoples construct identical physical wells.

## Distinct from direct sharing

Sharing with another individual copies a shard. Depositing in collective memory permits removal from one's own carried knowledge.

Archive capacity, access conditions, burden relief, whether retrieval copies, and treatment of obsolete or contradictory reports remain open.

## Source

Project conversation: [Morkahja live RPG](https://chatgpt.com/c/6aa08555-1c60-83eb-ae68-d3555edd8d7f), retrieved 2026-09-09. The complete retrieved conversation is preserved in [the source archive](../../Morkahja-Concept-Sources.md). Examples illustrate the concept; they are not exhaustive content lists.
