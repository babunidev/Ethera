# Knowledge Shards

**Status:** Established concept, consolidated from the project conversation; later user corrections take precedence.

## Meaning

A shard is a working term for a discrete piece of knowledge carried within a character. The conversation also considers trait-like question or need states that can match an answer. “Knowledge shards” and “spirit shards” were explored; naming and representation remain provisional.

## Example

A character who sees a bear gains knowledge of its location. Another needs to find that bear. A compatible question and answer enable an interaction, shaped by culture, roles, and relationship.

## Rules

- Person-to-person sharing **duplicates** the shard; the source retains it.
- A character can contribute a shard to collective memory and **relinquish** it personally.
- Offloading to the memory well allows the individual to lighten themselves.
- This is knowledge continuity, not ordinary exclusive item transfer.

Permanent character traits remain acquired. If both use a shared internal representation, the rules must still distinguish permanent qualities from relinquishable information.

## Open question from the last interview turn

Does each shard have its own weight or burden, or does accumulating more shards generally make a character heavier? No answer was present in the retrieved conversation. Capacity, aging of reports, copying fidelity, and retrieval rules are also unspecified.

## Source

Project conversation: [Morkahja live RPG](https://chatgpt.com/c/6aa08555-1c60-83eb-ae68-d3555edd8d7f), retrieved 2026-09-09. The complete retrieved conversation is preserved in [the source archive](../../Morkahja-Concept-Sources.md). Examples illustrate the concept; they are not exhaustive content lists.
