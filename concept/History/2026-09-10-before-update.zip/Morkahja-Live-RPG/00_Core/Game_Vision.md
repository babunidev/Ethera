# Game Vision

**Status:** Established concept, consolidated from the project conversation; later user corrections take precedence.

## The experience

Morkahja Live RPG is a shared, persistent 3D world for temporary roleplay. A player enters an existing life, chooses from available characters, and inhabits one for a session. The character already has a place in society, qualities, knowledge, and a history. The world owns that person; the player does not create or permanently own an avatar.

The same person is an NPC under AI control and a player character while inhabited. Logging out leaves the person in the world, where life continues and another player may later take over. Sessions should feel like joining a tabletop roleplaying adventure: immersive, meaningful, and temporary, without pressure to stay for hours.

## What persists

Characters, community, knowledge, objects, and world history persist. The village benefits from a hunt, discovery, or successful adventure and also shares the effects of failure. Character development exists, but its gains belong to that person in the world, not to the account currently controlling them.

The account has no permanent gameplay possessions or progression. A lightweight diary of past participation remains an optional idea.

## Setting and scope

This is the same Morkahja as the existing game world, in a far earlier age of small isolated elemental communities and emerging magic. It is a multiplayer RPG, not a settlement-building game. Players act as people within an autonomous society.

See [Core Game Loop](Core_Game_Loop.md), [Ancient Morkahja](../01_World/Ancient_Morkahja.md), and [Character Selection](../05_Gameplay/Character_Selection.md).

## Source

Project conversation: [Morkahja live RPG](https://chatgpt.com/c/6aa08555-1c60-83eb-ae68-d3555edd8d7f), retrieved 2026-09-09. The complete retrieved conversation is preserved in [the source archive](../../Morkahja-Concept-Sources.md). Examples illustrate the concept; they are not exhaustive content lists.
