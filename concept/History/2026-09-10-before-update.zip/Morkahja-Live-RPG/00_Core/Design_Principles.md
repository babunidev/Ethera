# Design Principles

**Status:** Established concept, consolidated from the project conversation; later user corrections take precedence.

1. **The world owns its people.** Players temporarily inhabit persistent characters.
2. **Play a person.** Settlement growth, construction, and organization arise autonomously; players have no village management interface.
3. **Keep sessions voluntary.** Players can enter when a character is available and leave without maintaining a personal MMO avatar.
4. **Progress horizontally.** Binary traits add possibilities and diversity. Existing traits do not decay or disappear.
5. **Let lives generate adventures.** Traits inform roles; roles and destinies generate side quests and the world content needed for them.
6. **Keep goals stable and routes dynamic.** “Obtain a bear claw” can remain valid after the bear dies and the claw changes hands.
7. **Preserve physical continuity.** Objects exist independently of quest acceptance and remain after objective completion unless consumed or otherwise physically changed.
8. **Expand and reuse.** Every destiny adds new content while vacant nodes gain new purposes, keeping journeys manageable.
9. **Embody information.** Character condition, direction, and interaction should be readable through bodies and the world, with minimal UI.
10. **Make community participation meaningful.** Shared work, knowledge, celebration, and relationships sustain people and society.
11. **Reserve destiny progression for players.** AI maintains life and explores within endurance limits.
12. **Communicate in the world.** Context, traits, roles, relationships, and matching knowledge generate interactions. There is no player voice or text chat.

Simplicity is a repeated priority. The design avoids numerical trait ranks, routine trait loss, and a competing account progression system. Large metaphysical consequences exist through dissolution and corruption.

## Source

Project conversation: [Morkahja live RPG](https://chatgpt.com/c/6aa08555-1c60-83eb-ae68-d3555edd8d7f), retrieved 2026-09-09. The complete retrieved conversation is preserved in [the source archive](../../Morkahja-Concept-Sources.md). Examples illustrate the concept; they are not exhaustive content lists.
