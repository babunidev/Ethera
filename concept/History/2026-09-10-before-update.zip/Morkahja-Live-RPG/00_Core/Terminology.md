# Terminology

**Status:** Established concept, consolidated from the project conversation; later user corrections take precedence.

| Term | Meaning |
| --- | --- |
| Morkahja | Existing elemental world, used here in an ancient era. Earlier transcription variants are normalized to this spelling. |
| Rokur / Embersworn | People of living flame; associated with Fyrskar Mountains. |
| Verdani / Bloomkin | Horned people of living water; associated with Evergrove. |
| Aevis / Windweavers | People of air and aether; associated with Celesterra and subterranean cities. |
| Grimnir / Stonewrought | People of stone, metal, and crystal; associated with floating Skylands. |
| Inhabitation | Temporary player control of an existing world character. |
| Trait | A binary, persistent quality; one has it or does not. |
| Birth traits | The 27 latent qualities drawn as 9 from each parent and 9 from the full pool. |
| Social role | A culturally interpreted calling assigned at adulthood, granting abilities and interactions. |
| Destiny | A personal procedural story direction beginning at adulthood; only players advance it. |
| Side quest | An associated objective that supports destiny and can award an experience-related trait. |
| Node | A world location or point of interest that can host changing narrative content when vacant. |
| Shard | Working name for a discrete piece of knowledge or a matching informational need. Exact relationship to traits remains open. |
| Memory well | Communal memory destination where an individual may deposit and relinquish a shard. Cultural form varies. |
| Godly essence | The divine vitality whose exhaustion leads to judgment at Atranor. |
| Atranor | Place where the gods decide continuation or dissolution. |
| Dissolution | Loss of individual existence; also described as a return to elemental unity. |
| Corruption | Transformation through corrupt magic into a being harmful to the world. |
| Stand-in | Opted-in queued player temporarily controlling a disconnected player's character. |

“Live RPG” is the project title. The established meaning in practice is persistent multiplayer simulation with temporary inhabitation, not a requirement for live-action physical roleplay.

## Source

Project conversation: [Morkahja live RPG](https://chatgpt.com/c/6aa08555-1c60-83eb-ae68-d3555edd8d7f), retrieved 2026-09-09. The complete retrieved conversation is preserved in [the source archive](../../Morkahja-Concept-Sources.md). Examples illustrate the concept; they are not exhaustive content lists.
