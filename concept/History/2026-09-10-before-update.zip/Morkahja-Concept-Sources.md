# Morkahja live RPG — source conversation

Retrieved 2026-09-09. Earlier ideas may be superseded by later replies. Speaker labels distinguish the user’s decisions from assistant interpretations.

## Turn ac24b68a-a4e5-4ce1-a26f-c735f6f66c01

### User

I want you to assist me in making a game. I want to make a roleplay game, a temporary roleplay game. What I mean by that is a game where the player logs in and chooses from available avatars, available characters, available avatars who are characters in a consistent game world. The world is there, and when I want to play in the world, I have to take over. I have to take control of one of the characters that are in the world. And by doing that, this character in the world comes with attributes and missions, depending on its function in the game world, because it should be somewhat a simulation of a clan, of a clan, or of a world with clans. And I'm thinking about quite a very old, ancient society, maybe even before agriculture. But I think we have settlements. I think of settlements with... yeah, there are settlements. I need you to keep that in mind and just let me brainstorm a little bit more. So just say that you got this part.

### Assistant

Got it.

## Turn 783f1ce7-70b9-4f83-91da-d8e43aab09ba

### User

And so when I imagine this world, it has, like, little buildings, just, like, palisades, or, like, wooden stronghold—not stronghold, but wooden fences, or walls around a village. A little bit like a tribe from Africa, or it has a savanna, or I wouldn't put it in one biome, but it looks like a prairie or savanna in my imagination. I think of a procedurally generated 3D map world that generates the world for the NPCs, or for the PCs that are also NPCs, and the NPCs that are also PCs. So the characters in this world, when they are put in the world, they create places on the map according to their mission and according to their goal, or according to their destiny. So they have destinies. Each one, when they are born into this world, they have a destiny, and they have side missions leading to this destiny, or making the way to this destiny. For example, missions that can help form skills or acquire items or knowledge that will help in reaching the destiny and the main mission currently. So each character that is born into the world has this timeline of its destiny that is the main quest and side quests. It also has a role in the society or in the community that it has to fulfill, for example hunters or warriors or stuff like that. And it all should lead to— let me put that here. You just say that you got this.

### Assistant

Got it.

## Turn 61860fd7-3736-4e34-8e1f-5b2df237dd53

### User

So I want the village work properly. There should be all roads for a village. Everyone should have a home or house. Everyone should have a partner. If they don't have a partner, they have to find a partner. They have to reproduce, because from reproducing you spawn in more characters, and more characters mean more players, or the world can take more players. So this is also a big feature of the game. We want that the game world is limited. So there is a limited amount of players that can play at the same time, and it depends on how successful the village is. Of course, if I log out, someone else can take my place in the same character and continue the story of this character further. Yeah. So, but the way that the game grows, or the population grows, the way that the game gets more players is by the players being successful in creating more characters, or increasing the population of the village. Beside hunting quests and beside this main quest and the side quests, a tree that each character has and each character has created in a kind of random fashion, or in a fashion that expands the game world. Besides that, there is, of course, all the missions, or all the tasks that the community has to be successful, and that is getting enough food, being safe, so not dying, being healthy, having enough fun, like social events and stuff. Create the circumstances to have these events by having enough food, having clean water, having it warm in the night, and so on. So there will be missions, general village missions, and then there will be the individual missions. I put this here, and just tell me that you got this.

### Assistant

Got it.

## Turn 68bb30f7-c1fd-45a2-a0d0-3a3cb10ec323

### User

Playing this game should just be a little bit like a session in a roleplay game. It should be a little bit like... it shouldn't force me. It shouldn't force me to stay long. It shouldn't force me to spend too much time. It should be something that I can dive in and that I can enjoy and that I can immerse myself in, but that I know is temporary. So nothing of... Of course, the player himself, he has like a progress somehow in his player account, maybe, but in the game, the progress is not individual. The progress is the village or the community itself. So what I achieve inside the game is never for me individually, but for the village. So all the success that I bring is for the village. And if I'm unsuccessful, of course the village is suffering that too. But at the same time, it is just me diving in whenever there is a free slot and I have time, and sometimes I have to wait, or sometimes I have to hurry maybe. Maybe I get a notification that not enough people are taking care of the village, the village is suffering because not enough people are active. But also the question is if the characters are active, even if not every character is occupied by a player. I think that's definitely a thing that we should include, that the characters have an artificial intelligence, or have an intelligence that makes them fulfill their role in the community as good as it goes, or as, yeah, just a basic level of participation, even if they are not controlled by a player. I put this here, just tell me that you got this.

### Assistant

Got it.

## Turn e98fc1dd-411d-4f0f-b780-a02a2edfa8ea

### User

So, like I said, the game should be a 3D game, I want it to be, from the perspective to be similar to, like, a game like Dota 2, or, yeah, or maybe a Baldur's Gate 2, or Icewind Dale, some... but it's 3D. I want the atmosphere, I want it to be a little bit in the direction of games like Morrowind, for example. So a little bit more serious fantasy, not necessarily dark fantasy, but rather dark fantasy than light fantasy. I want it to be serious and intense. I want there to be very subtle, no very... I want there to be very strong but very rare magic. But, yeah, nothing like mages or something, but more that we... more something that is primal, like a shaman and a druid. Because this game is very long-ago time, like Paleo, or I don't know, something very long ago, ancient people are making stone circles and building some weird shrines or altars from nature and natural materials, and maybe even sacrificing animals or other sacred gifts to some gods. Of course the game is, of course, taking place in the world of Mordkarya, my other game world, because that is pretty much given. But it is before magic, or at least in the beginning where magic arrives in the world. I put this here and you just tell me that you got it.

### Assistant

Got it.

## Turn 45e8f44d-6c98-49ef-9d33-0dc3efb402ba

### User

When I think of the game, I'm thinking of small groups of adventurers going to overlapping adventures, venturing out into the world. And I think it is one can easily think of it as a group. It's a random group finder. And that is not a random group finder, that is created quest chain overlaps that are given to the characters. So, like I say, one character has a main quest and several side quests, and some characters can have overlapping side quests. Maybe one needs to kill a bear to get a claw, and another one needs to kill a bear to get, I don't know, the heart or whatever for one of their quests. And these, of course, create the opportunity in the world to get this. So the bear is not existent before, but the bear is actually being put in the world and also getting a location in the world when the character with the quest is created. If someone else kills the bear before, then the objective, then it will be like that the quest will never be kill a bear, because that is not a quest that should exist. But the quest would be get a bear claw. And the first, of course, if the bear is somewhere alive in the woods, my quest will lead me there. But if I get there and I see that the bear is already dead, maybe someone else killed the bear, then the quest will somehow lead me to somewhere where I can get this claw, maybe it has been sold to a merchant, or it has been lost somewhere, or it has been taken somewhere. So that's how the quest should dynamically change and keep being focused on the goal and not just spawn a new bear just because someone else has the quest, but actually repurposed the items, as long as they exist in the world, have them exist consistently. So we don't delete the bear claw when it's given to the quest giver. We don't do that. We actually keep it in the game. So everything that is looted has a purpose. Besides, of course, things like food that is eaten, we can't just keep that in the game. Of course, there has to be a production. But yeah, I put this here, and you just tell me that you got it.

### Assistant

Got it.

## Turn 1c7d9168-bd13-41c7-8553-74d1ade544ab

### User

That is also something that I really, I don't like in other games, that mobs constantly respawn, and also that when I have a quest and I should kill ten bears, but I have killed ten bears before that, before I got the quest. I cannot use that to already have done this quest. A better example is if I have to collect ten linen cloth from special linen cloth. But I have been there and I had the chance to get this item, these items. I could have them if I would have been allowed to get them on the loot table, because I don't have them because I don't have the quest. But they should have this, of course, anyways. So I could have them already, have the bear claw already, or the bear pelt already in my inventory, already somehow, and I should be able to finish the quest immediately. And that is something that I never like in other games, because it's so limiting, that I only can... that the quests are always only from one side and not from the other. Because I should be able to kill the boss, get his head, and then get the reward, then take the quest to kill the boss and get the reward for killing the boss, because I have the head, or I have the ear, or I have whatever part they desired, or whatever part I thought would be good to take with me. Yeah. But except, okay. So the world is generated around the randomly generated quests, or the randomly chosen quests for each character, and each character spawns in the parts it needs to create a neat little story. That way the world can be very unexplored, and it will also always be somehow different. If there was on this spawn point, maybe there was a bear before, but for the new quest there should be an apple tree. So suddenly on this spawn point, or this point of interest, there will be an apple tree. And before there was a bear. And the same way it can... So we can have it like nodes. Each node can spawn in the quest objective. And if it is, if we, for example, killed the bear and the quest is accomplished, quest is done, then we can use this node to spawn in something else. Or we... yeah, maybe. But it depends. For some things we need new spawn points. For some things we can reuse the old spawn points, or the old nodes, quest nodes. Yeah, I put this here and you just tell me that you got it.

### Assistant

Got it.

## Turn c8162ab5-3906-4204-b6bc-da6b4f12ec3c

### User

From the art style, yeah, I want it to be quite dry. I don't want it to be very, very playful or something. I would say a little bit in the direction of World of Warcraft Classic, but a little bit more serious and less comic style. I am thinking of a little bit stylized, but in a way where it's not as clear as of what it is, so it allows more imagination. So it should not. It maybe should be a little bit distorted, or have a lot of flowing energies, have a lot of movement in the ground, have a lot of magical elements where you see, okay, there's some magic. The world is actually, there's magic pouring out of the world right now, or it's soaking in everything and going in and out, and a little bit, could be a little bit like on a trip or something. I want this to be a very immersive experience. I want as little UI as possible. I want as direct controls as possible. I'm not sure if it should be third person. I still think, have it like a MOBA, like Dota, for example, very direct controls, very precise movements. That would be very cool. I can imagine it be cool to have abilities, of course, that you can learn or develop. There should be, I wonder, maybe there should be close proximity voice chat to just be, like, in the game, but also really, like meet the people that you're around with. Proximity voice chat. We don't have any NPCs in the way where we have to talk to them, and no one is giving us the quests. The quest comes from visions, or comes from ourselves. The quest has to soak into the character. I would like the world to give as much sense as possible for things that are usually very underrated in other games. For example, in many role-playing games, the role-playing factor is never really part of the gameplay, and I would like to change that in many ways. But just giving importance to social interaction inside the community, inside the village, making it something that is actually representing how it actually works in real life or in our history, that good moments with the community make people stronger, make people more resilient, make people more decisive. So that it is important that there is social interaction, like dancing with each other or making music or having intercourse. Of course everything is gonna be 18 plus, so there should be some spicy stuff as well. But also just working together, working in a team. So I put this here. Just tell me that you got this.

### Assistant

Got it.

## Turn 09a190ba-21ed-4ee2-a418-cfcf8a1005ae

### User

I would like you to summarize all this and then ask me one question at a time, interview me about the game and ask me everything you need to know to fully understand my vision for this game. get the name right, its Morkahja, same game world like the game i already created

### Assistant

## Morkahja: Temporary Roleplay Game Concept

This game takes place in **Morkahja**, the same game world as your existing game, but in a much earlier age. Civilization is still young. Settlements are small, nature dominates the landscape, and magic is only beginning to seep into the world.

### The central idea

The player does not create a permanent personal character.

The **world owns the characters**.

When a player enters the game, they choose from currently available people who already exist within the world. They temporarily inhabit that person and continue their life. When the player leaves, the character remains part of Morkahja. Another player may later take control of the same person and continue from exactly where their life has gone.

Every playable character is therefore simultaneously:

- a persistent person in the simulation,
- an NPC when nobody controls them,
- a player character when somebody inhabits them.

The game is about **temporarily becoming someone who already belongs to the world**.

---

## Persistent community rather than personal progression

The real persistent "character" of the game is the **village or clan**.

Players may have some account-level progression, but the important achievements inside the world belong to the community.

If someone returns from a successful hunt, everyone has food.

If someone discovers a water source, the settlement becomes stronger.

If warriors fail to protect the village, everyone suffers.

If the village grows prosperous enough for families to grow, new people are born.

Those new people become **new playable character slots**.

The population of the world therefore determines how many people can simultaneously play. The community literally creates its own server capacity through survival, relationships and reproduction.

---

## A living village

The settlement should function as an actual society rather than as scenery.

People need:

- homes,
- food,
- clean water,
- warmth,
- safety,
- health,
- tools,
- social relationships,
- partners,
- children,
- meaningful work,
- communal gatherings,
- entertainment and ritual.

People have social functions such as hunters, gatherers, warriors, craftspeople, healers, spiritual figures and whatever other roles emerge from Morkahja's society.

Characters without players continue performing their ordinary responsibilities through AI. Player control allows a person to behave with much greater intention, creativity and ambition, but the village does not freeze because somebody logged out.

---

## Characters have destinies

Every person born into the world receives a **destiny**.

This functions somewhat like a procedurally generated personal campaign.

A character may have:

- a distant destiny,
- a current major objective,
- several connected objectives,
- opportunities that develop skills,
- objects they may eventually need,
- knowledge they may have to discover,
- relationships that become important,
- events that move them toward or away from their destiny.

The player is not simply following a quest log. They are stepping into an unfinished human life.

The person's societal role exists alongside this destiny. A hunter still needs to feed the village even while pursuing whatever strange path their life has taken.

---

## Adventures emerge from overlapping lives

Characters' objectives deliberately intersect.

One person may need a bear's claw.

Another may need its heart.

Another may simply need meat for the settlement.

Another may have learned something about the place where that bear lives.

Their stories naturally pull them toward one another.

The result resembles an RPG party finder, except **the group exists because their stories overlap** rather than because the game put four players into a matchmaking queue.

Small temporary bands leave the village together, accomplish whatever brought them together, and eventually separate again.

---

## The world grows around people's stories

Procedural generation is tied directly to characters and their destinies.

If someone's story requires a particular bear to exist, that bear is placed somewhere meaningful in the world.

If another story requires an ancient stone circle, unexplored valley, apple tree, strange shrine, cave or abandoned camp, the world can create the circumstances necessary for that story.

Character generation therefore gradually produces **world generation**.

People are born.

Their potential stories require places.

Those places expand Morkahja.

The unexplored world effectively grows outward through the lives of its inhabitants.

---

## No conventional quest logic

The game does not think:

> Kill the bear.

It thinks:

> Obtain the bear's claw.

That distinction is fundamental.

The bear is a real creature in the world. Someone else might kill it.

If that happens, the quest does not spawn another identical bear.

The claw continues existing.

Someone might take it.

They might sell it.

A trader might carry it somewhere.

It might be placed inside a house.

The owner might die and drop it.

Eventually the character seeking the claw can discover what happened and pursue it.

The **goal remains stable while the path changes dynamically**.

---

## Objects belong to the world

Quest items are not special abstractions.

A bear does not suddenly gain a claw because someone accepted a quest.

It always had one.

If you killed the bear yesterday and kept its claw, and today circumstances create a reason for someone to need that claw, you already possess the thing they are searching for.

Likewise, completing an objective does not normally make the object vanish.

Objects continue through the simulation until something physically consumes, destroys, transforms or decomposes them.

Food can be eaten.

Wood can be burned.

A hide can become clothing.

A sacred object might survive generations.

This makes history physically accumulate inside the world.

---

## No endless respawn treadmill

Animals and enemies should not endlessly materialize because a timer expired.

If a bear dies, that bear is dead.

A location that once contained the bear may eventually acquire an entirely different purpose.

The procedural system contains **world nodes or potential points of interest** that can participate in stories. Some can be reused after their purpose ends. Others permanently alter the world and therefore remain.

The map slowly becomes a patchwork of the things that have actually happened there.

---

## Session-based roleplay

Playing should feel closer to joining a tabletop RPG session than maintaining an MMO character.

You enter when you want.

You see which lives are currently available.

You choose one.

For a while, that person's problems become your problems.

Then you leave.

There should be little pressure to remain online for hours. Individual ownership is deliberately weakened. Someone else may continue the person's life after you.

The emotional investment instead comes from thinking:

**"I was part of what happened to this village."**

---

## The ancient Morkahja setting

This takes place extraordinarily early in Morkahja's history.

The world evokes prehistoric or proto-civilized societies rather than medieval fantasy.

There are villages surrounded by wooden fences or palisades, primitive houses, natural shrines, stone circles, ritual spaces and small communities surrounded by enormous stretches of wilderness.

The landscape currently feels somewhere between prairie and savanna in your imagination, although the world itself should contain multiple biomes.

Agriculture and settlement technology still need to be pinned down historically within Morkahja's own development.

---

## Magic

Magic should be **powerful and rare**.

There are no ordinary fantasy mages throwing spells everywhere.

Magic feels older, stranger and less understood.

Its practitioners would be closer to shamans, seers, ritualists or druids.

Stone circles, sacrifices, natural shrines, visions, sacred places and strange phenomena belong naturally to this period.

This is also an important age in Morkahja because it occurs around the time when **magic begins entering or awakening within the world**.

The environment itself can visibly suggest this. Energy seems to flow through terrain, matter and living things. Reality occasionally feels slightly distorted or unstable, almost dreamlike.

---

## Visual direction

The game is 3D.

The camera currently leans toward an elevated perspective resembling **Dota 2**, rather than conventional over-the-shoulder third person.

Movement should feel direct, precise and physical.

The visual language is stylized without becoming cartoonish.

There is some World of Warcraft Classic readability, but:

- drier,
- more restrained,
- more serious,
- less exaggerated,
- less visually explicit,
- more dependent upon suggestion and imagination.

Morrowind is an important atmospheric reference: strange, ancient, serious and somewhat alien without simply becoming grimdark.

---

## Interface

The interface should almost disappear.

The player should primarily perceive:

- their character,
- other people,
- the landscape,
- sounds,
- gestures,
- movement,
- objects,
- events.

Traditional RPG abstractions should be hidden whenever the world itself can communicate them.

Even quests should not necessarily arrive from NPC dialogue boxes.

A character's purpose can emerge internally through **visions, memories, instincts, dreams, knowledge or conviction**.

The quest should feel as though it belongs to the person's mind rather than to the UI.

---

## Social interaction as gameplay

Roleplaying should have mechanical meaning.

Human connection is part of survival.

Eating together, celebrating, dancing, making music, working together, intimacy, ritual and communal events can improve psychological and social qualities such as resilience, confidence, morale, loyalty or determination.

Community festivities therefore matter just as much as constructing a wall or hunting food.

For an adult-rated game, sexuality and intimate relationships can also exist as part of human social life rather than being artificially erased from the world.

Proximity voice chat fits this philosophy particularly well. Meeting another character can also mean genuinely meeting whoever currently inhabits that person.

---

## The fundamental structure

At its core, Morkahja becomes a game about:

**World → Community → Person → Destiny → Adventure → Consequence → World**

The world produces people.

People acquire destinies.

Destinies create places and circumstances.

Those circumstances cause people to meet.

Players temporarily inhabit those people.

Their actions change the community and landscape.

Those changes become the conditions inherited by future characters and future players.

Nothing truly belongs to the player except their memory of having been there.

### Question 1

When you imagine logging into Morkahja and seeing the available characters, **what information about each person should you know before choosing one?**

## Turn e1c6bf47-3ace-4298-82f0-51ca3ae2b891

### User

I think here we can really, here we can tell the story. Here we can give some lore, because we don't necessarily need to actually have something like a quest log in game. So if I log in, or if I start the game, and I see the available characters, I will see what kind of destiny they have, because that gives the player the choice of, do I want to have a very thrilling adventure today, maybe including a fight, or something creepy, or do I want to have a very mysterious adventure, where I have to find a place, or explore a place, or have to maybe find some clues or hints, or collect some knowledge for the community. So here in the selection of characters, I can choose what kind of game I want to play today, if there is so many available. And if not, I will log in, or I will start the game, and I will see, ah, this is the character that I can play now. If I want to play him, or if I want to play them, then I can do that, or otherwise I let someone else play, if it's something I really don't like to do. Like maybe someone don't want to go out and kill a bear. But yeah, so this is where we can give the player an insight of what this character in this world is about, and what why they are striving for, what goal or destiny they have. Yeah.

### Assistant

That makes the **character-selection screen part of the storytelling system**.

Before entering the world, the player gets a concise glimpse into each available person's life: who they are, their role in the village, what currently troubles or drives them, and the broader destiny pulling them forward. It effectively replaces much of the conventional quest-log function.

The selection becomes a choice of experience:

- dangerous or combat-heavy,
- mysterious or investigative,
- exploratory,
- social,
- spiritual,
- practical village work,
- knowledge gathering,
- or some mixture.

The player is not selecting a class or build. They are selecting **whose life they want to inhabit for this session**.

### Question 2

Once I take control of a character, **how much freedom should I have to ignore their destiny and do something completely different?**

## Turn cd85e834-9a2a-4e54-9d1e-5ff792609a72

### User

That's an excellent question. Excellent question. Absolutely excellent. So I think someone who doesn't follow their destiny will become more and more become sick, will become mentally unwell, and that means the less I work towards my destiny, the worse I will become. So, and that will be if we imagine the characters that we are playing in Markaya, they are one of the four elemental races of Markaya, that are the Avis, the Vedani, the Rokur, and the Grimnir. And each of them have very, very specific behavior for when they are not doing well, for when they are not functioning in their society, when they are being corrupted. And it is actually a pretty big part of the game, a pretty big alternative destiny to become something that is either the pure form of the element without the individual. So, for example, the Vedani, being a water being, they would actually become water and just dissolve into nothing when they are too connected with water, for example. And the same would be when they are too weak to maintain their integrity as an individual. And that would be the case when they are too long not following their destiny. And another, there's another path that it can go, and that is when the being is connecting itself too much with the magic. There's one particular corrupt magic that when they connect, they will actually turn into a totally different being, into something that is sick and sickening to the world. So this is pretty much the danger, and this is something the player can experience. And it will not be warned for or something. It will then happen when the player is not reinforcing the individual of the character, of the figure in the game, of the being, and not reinforcing by following their destiny and being a productive, or not productive, but being a participant in the community of individuals.

### Assistant

That establishes a major law of Morkahja:

A character has freedom, but **freedom has metaphysical consequences**.

Destiny is not a quest marker imposed from outside. It is part of what keeps an individual coherent as a person. Following it, participating in society, forming bonds, and acting as a distinct being reinforces the character's integrity.

Neglecting that path gradually weakens them.

For the four elemental races, that deterioration expresses itself according to their nature. A Vedani, for example, can lose the boundaries that make them an individual and eventually dissolve back into water. The same principle would manifest differently for the Avis, Rokur, and Grimnir.

There is also another danger: instead of losing individuality by collapsing back toward the pure element, a character can become increasingly bound to a corrupt form of magic and transform into something alien and harmful to the world.

That gives the character three broad existential directions:

**Individuality**
The person follows their destiny, participates in society, forms relationships, and strengthens their existence as a distinct being.

**Dissolution**
The individual weakens until the element overwhelms the person and the self disappears.

**Corruption**
The individual reaches toward the wrong kind of magic and becomes something else entirely.

Crucially, the game does not announce these as a morality meter or warn the player that they are accumulating "corruption points." The player experiences the consequences through the character and the world.

### Question 3

When a character begins drifting toward dissolution or corruption, **what should the player actually notice happening to them before the transformation becomes irreversible?**

## Turn 1f7a9551-39ff-4432-bb7b-40b41e875a3e

### User

Well, there's the fact that it can actually... it's actually... I have the idea that the character actually embodies things like that. When they are not doing well, they will be less defined. When they're feeling small, they will be smaller. When they're feeling thin, they will be thinner. When they're feeling transparent, they will be transparent. So there can be things happening to the characters when they really, when they have good energies, they're really good mood. They might be shining. When they feel strong, they might be more muscular. So the world itself and the character itself should embody the state of their well-being.

### Assistant

That means the character's inner state is not hidden behind numbers. It becomes visible in their body, presence, and material form.

Well-being is embodied.

If a person is thriving, aligned, and full of good energy, they may appear stronger, brighter, more vivid, more stable, more beautiful, more physically defined.

If they are weakening, alienated, or losing themselves, their form begins to reveal it. They may become smaller, thinner, dimmer, less solid, more transparent, less distinct, less fully present.

So the player reads the condition of a being directly through the being itself. The body becomes the interface for health, mood, integrity, and spiritual danger.

That fits the whole direction very well, because it keeps the game diegetic. The world shows the truth instead of a UI panel telling it.

### Question 4

What is the basic shape of a single play session in Morkahja?

From login to logout, what usually happens in one session?

## Turn a12e8200-524a-4cf5-a832-842d5a86d819

### User

I mean, that pretty much depends on how long the player is engaged. But, so the game will always show the player a little bit in what direction the character wants to go, pretty much. It might blow in that direction. The wind might blow in that direction. The game might show some light or something highlighting in the right direction. So when I join the session and I have no idea where in the life of this person I am right now, I do have an idea. I do have an idea. I have a goal. I already know when I choose this character that I have to find a certain plant somewhere in the woods. And the game gives me hints in what direction that is, but the game also allows me to tap into a community knowledge source and get clues, or get update my knowledge if I have no idea where to go. But one way, of course, is that I can ask whoever is around if they know how to get to this forest, and maybe they can answer me, or it is written in the knowledge pool, and I can access this knowledge to get clues. And the clues could be signs, signs like not UI or not a compass or something, but signs like we expect when we ask for a sign of God, for example. And we ask, God, give me a sign, what direction should I go? And then a bird will fly up from a bush, maybe a white dove, maybe a strong gust of magic goes through the character and pushes them in that direction. Or just one can see that all the little stones of a grimnir that are usually just floating around their shoulders and head, they all pull in one direction. So if we observe the game, we know where to go. And then it is pretty much just following. Either we follow it, or we ignore it, and either we follow it and make progress in the storyline of this character, or we just explore whatever else and we find other stuff. And there it is also important that we can also be a participating part of the community by just exploring. Because if we explore, just run around and explore, do whatever, we will always, when we go back to the village, for example, we will always bring knowledge. We will bring knowledge about maybe we have seen a bear, maybe we have found an item that we can give to the community, or at least the knowledge that we have this item, we will give to the community. And therefore the community can know that we have the item in case they need this item. So pretty much jump in, move around with the character, get information, maybe talk to someone, maybe find someone who has the same direction right now, who has the same signs, or when we meet, we suddenly start being stronger or start being drawn in the same direction together. And then just walking around, finding things, exploring things, discovering things. Maybe we see something glittering in the trees, and if we are a good climber, maybe we can find something there. All these different parts of everything that we could do in an RPG should be somehow represented in a way. But it is a lot about exploring, exploration, finding stuff, finding knowledge, and bringing that knowledge back to the village. And I think there should be something like that the character gets tired maybe. So we could go for that mission and just follow this straight away, and we would have enough time to achieve that and come back to the village and bring back this spoils of our adventure. But we could also just wander around, and at some point we are just tired, getting tired, and we have to replenish our energy. I would even say that one first sign is that the character gets tired when they are just wandering around without an aim. But if they are following their destiny only, then they will replenish their energy and they will not get tired. So the first sign of not being well is being tired, and then they want to go back home and kind of recharge in a social situation. But yeah. Also, I added a source with the names for the races and a little bit of a background for each race. You can take a look if you find it in this project. So you get the names right and you get a little bit of a background about each race.

### Assistant

Yes. I checked the Morkahja world source, and I have the names and identities straight now:

- **Rokur, the Embersworn**: beings of living flame, clan-oriented, disciplined, communal, tied to craftsmanship, responsibility, hearths, and containing their own strength.
- **Verdani, the Bloomkin**: horned beings of living water, expressive and communal, closely tied to healing, stewardship, music, festivals, water, gardens, and ancestral memory.
- **Aevis, the Windweavers**: beings of air and aether, shaped by learning, mentorship, disciplined magic, architecture, crystal craft, and the need to maintain the conditions that keep their bodies coherent.
- **Grimnir, the Stonewrought**: beings of stone, metal, and crystal, strongly connected to creation, craftsmanship, memory, architecture, navigation, and shaping their communities through what they make. fileciteturn0file4

So earlier where I used **Vedani** and **Avis**, that was wrong. It is **Verdani** and **Aevis**.

Your description also clarifies what a normal Morkahja session actually feels like.

The player enters an already ongoing life. They know the character's current destiny from the selection screen, so they are never dropped into complete confusion. Once inside, the world itself begins gently orienting them toward what the character seeks.

There is no glowing minimap arrow. Direction appears through **signs**.

The wind might lean toward the destination. Light might fall strangely across one path. A bird might suddenly rise from the correct direction. Magic could physically move through the character. A Grimnir's floating stones might all begin tugging toward the same horizon.

The more closely the player observes the character and environment, the more readable these signs become.

Knowledge provides another layer. The village possesses a kind of **collective knowledge pool** built from what its inhabitants have discovered. If someone has previously encountered the forest, creature, plant, place, object, or phenomenon you seek, that knowledge can help guide you. And the most direct knowledge system is still another person: you can simply ask whoever is nearby.

That makes information itself part of the village economy.

Exploration feeds this system even when the player completely ignores their destiny.

If you wander into the hills and encounter a bear, the village can later know that a bear was seen there.

If you discover an unusual plant, that becomes knowledge.

If you find an object and keep it, the community can know that this character possesses it.

If you find a cave, shrine, spring, ruin, dangerous route, useful tree, or strange magical phenomenon, you have contributed something simply by returning with knowledge of it.

So even apparently aimless wandering can still constitute **participation**.

Sessions can also naturally create groups. Two characters may notice that their signs point in roughly the same direction. Being near each other might even strengthen or alter those signs, revealing that their destinies currently intersect. They leave together without ever entering a matchmaking interface.

And fatigue becomes another piece of diegetic guidance.

A character who wanders without purpose gradually tires. That tiredness is one of the earliest indications that their inner coherence is weakening. Eventually they feel drawn home, where food, rest, companionship, ritual, conversation, intimacy, music, or simply being among their people restores them.

A character actively moving with their destiny behaves differently. Purpose itself can sustain them. Following that path may preserve or even restore energy rather than draining it.

That makes **purpose literally animating** in Morkahja.

### Question 5

When knowledge returns to the village, **who or what actually remembers it?**

Is there a literal communal place such as a storyteller, memorykeeper, shrine, pool, stone, archive, or gathering place, or is shared knowledge something more supernatural that every member of the community can somehow access?

## Turn ea1f319e-baeb-4228-b420-6b9c177c06ed

### User

See, I already, I already asked my worldbuilding AI agent to get this information for you long before you now asked for it. It is, it is pretty much, yeah, apart. I just give you the whole article that I extracted from the agent.

Yes—**all four peoples already have traditions in your lore that can support this.** You could make visiting the settlement’s knowledge keeper a natural first step when a player needs an animal, material, unusual object, or particular person.

The foundations already exist; using them to retrieve everyday clues would be a gameplay extension.

| PeopleWhere they already preserve knowledgeHow it could work for the player |                                                                                                                                                                |                                                                                                                                                                                                                                          |
| --------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Verdani**                                                                 | **Memory Pools**, tended by Memorykeepers. Your lore explicitly describes them as libraries and communal archives, storing experiences in enchanted water.     | Visit a local pool and ask its keeper for relevant memories. A contributed sighting could reveal a recognizable landmark, an animal’s habitat, or the person last seen carrying an object.                                               |
| **Rokur**                                                                   | **Clan-Hearths**, which already serve as historical archives and educational centers. Hearthkeepers and storytellers preserve knowledge through oral teaching. | Ask at the communal hearth. The keeper recalls local reports or introduces you to a hunter, traveler, or craftsperson who knows more. Information comes through conversation and remembered directions.                                  |
| **Aevis**                                                                   | **Crystal archives, harmonic chambers, and Resonance Archives**. Their libraries preserve memory through resonance, and knowledge repositories are communal.   | An archivist retrieves relevant records: an expedition’s observations, an object’s description, or a documented location. This is the strongest foundation for a formally organized, searchable library.                                 |
| **Grimnir**                                                                 | **Memory stones**, architectural records, and **Skykeepers**, who carry history between Skylands as living archives.                                           | Consult a local Memory-Keeper and their stones. Visiting Skykeepers could bring reports from other Skylands, while craft lineages help identify objects and locate their makers. A dedicated consultation space would be a new addition. |

These foundations come from your [Verdani notes (line 238)]\(C:/Users/Babun/Documents/Morkahja/MorkahjaWorldBuilding/Lore/Races/Verdani.md:238), [Rokur notes (line 143)]\(C:/Users/Babun/Documents/Morkahja/MorkahjaWorldBuilding/Lore/Races/Rokur.md:143), [Aevis notes (line 206)]\(C:/Users/Babun/Documents/Morkahja/MorkahjaWorldBuilding/Lore/Races/Aevis.md:206), and [Grimnir notes (line 119)]\(C:/Users/Babun/Documents/Morkahja/MorkahjaWorldBuilding/Lore/Races/Grimnir.md:119).

**The key addition is that these places collect current local knowledge alongside history.** Hunters contribute sightings, travelers report routes, craftspeople describe what they make, and residents share what they have available to trade or lend. The keeper helps people find the relevant information.

For gameplay, a question could produce several useful kinds of answer:

- **Available here:** “We have that material in the communal stores.”
- **Someone has it:** “The potter has one and may exchange it.”
- **Known location:** “Look beyond the split stone, along the northern stream.”
- **Recent sighting:** “A hunter saw a bear there three mornings ago.”
- **Someone knows more:** “Speak to the scout who returned yesterday.”

Those are illustrative examples, rather than existing lore.

I would make **each place know what its community has learned and shared**. A bear sighting can become outdated; a strange object might only match an incomplete description. Small villages have fewer reports, while larger settlements and traveling keepers expand the available knowledge.

That gives you the loop you described: **ask locally → obtain a useful lead → visit the place or person → bring new knowledge back.** The player benefits from other people’s discoveries and can contribute their own, with each culture giving that same function a distinct experience.

### Assistant

That answers the knowledge question completely.

In Morkahja, **knowledge is culturally embodied rather than accessed through a generic global database**:

- **Verdani** use Memory Pools and Memorykeepers.
- **Rokur** preserve knowledge through Clan-Hearths, Hearthkeepers, storytellers, and oral memory.
- **Aevis** use crystal archives, harmonic chambers, and Resonance Archives.
- **Grimnir** use memory stones, Memory-Keepers, Skykeepers, and records embedded in craft and architecture.

These systems preserve both **history and current practical knowledge**. Hunters report sightings, travelers report routes, craftspeople report objects and materials, and people can contribute information about what they possess or have encountered.

The information is also imperfect and temporal. A bear sighting from three days ago means only that a bear was there three days ago. A description may be incomplete. A small settlement knows less than a large one. Traveling knowledge keepers can physically spread information between communities.

So the knowledge system itself becomes part of the simulation rather than an omniscient quest database.

### Question 6

When nobody is controlling a character, **how far should that character's AI be allowed to advance their personal destiny?**

Should they merely maintain daily life and their community role until a player inhabits them again, or can an unplayed character actually pursue objectives, discover places, form relationships, fight, complete major parts of their destiny, and potentially even die without ever being controlled by a player?

## Turn d930f001-c4c9-48dc-983a-78de2b8e4db6

### User

That's very good question. I like the idea of the character being able to pursue objectives from the personal destiny. But I think for the gameplay and for the... I think it is better if only the player can follow the destiny. I think it is good if the NPC or the character's AI is allowed to explore and journey around, but only in the way that is limited by tiredness. So it's pretty much when the AI explores outside as well and collects knowledge, even if only until they're tired, and then they come back and they replenish by participating, by doing purposeful tasks in the society. Because that is of course also a way to stay good, stay healthy, by not necessarily following their own destiny, but by just being a purposeful participant in the community.

### Assistant

That creates a clear separation between **life simulation** and **destiny progression**.

When a character is not controlled by a player, the AI can:

- perform their societal role,
- maintain relationships,
- eat, rest, work, and participate in communal life,
- explore nearby territory,
- discover places, creatures, materials, dangers, and objects,
- contribute that knowledge back to the settlement,
- travel within the limits of their endurance.

But the AI does **not** advance the character's personal destiny.

Destiny remains specifically tied to player inhabitation. The character's deeper story only moves when someone steps into that life and chooses to pursue it.

That also means there are two distinct ways a character maintains their integrity:

**Personal purpose**
Following their destiny directly strengthens them.

**Communal purpose**
Working, helping, socializing, protecting, gathering, crafting, teaching, caring for others, and otherwise participating meaningfully in society also keeps them healthy and grounded.

Aimless wandering drains them. An AI may explore, but eventually fatigue pulls the character back toward the community, where purposeful activity restores them.

This makes the player special without making the NPC state artificial. The AI keeps the person alive. The player moves their life forward.

### Question 7

How permanent should **death** be?

If a character dies while controlled by a player, or dies because of something that happens while the AI is controlling them, is that person permanently gone from Morkahja and their playable slot lost until another person is born?

## Turn 04a95aed-e2b7-498a-a75d-7db11bc37de6

### User

In this world, death... In this world, death is one thing that is only decided by the gods. When someone is out of favor, has used their godly essence, they will be brought to a place called Atranor. A-T-R-A-N-O-R. And there they will be judged by the gods. If they may continue, or if they vanish, dissolve, if they become one with everything. So that's pretty much the options. They either disappear when the gods don't give them another chance, or the gods give them another chance, and they come back to life. Or not. They don't come back to life, but they pretty much don't. They continue living. They will be replenished in God's essence, and they will continue their journey towards their destiny. If they don't, if they're unlucky, if the gods don't agree to them continuing, they will just disappear. And maybe they will be repurposed in a way. Their essence will be repurposed and given to a new being. And what I mean is their destiny and their role is being put back into the pool that new characters are made from.

### Assistant

That makes death in Morkahja fundamentally different from ordinary RPG death.

A character does not simply die because their body reaches zero health.

When their **godly essence is exhausted**, they are taken to **Atranor**, where the gods judge whether that individual may continue.

There are two outcomes:

- **Continuation:** the gods replenish the character's godly essence and return them to their life so they can continue toward their destiny.
- **Dissolution:** the gods refuse continuation. The individual ceases to exist as that person and becomes one with everything.

What disappears is the individual, not necessarily everything that constituted them. Their **role, destiny components, narrative functions, and perhaps parts of their essence return to the world's generative pool** and can later become ingredients in the creation of another person.

So even permanent loss feeds the simulation.

This also means dangerous gameplay can remain genuinely dangerous without making every defeat automatically permanent. Atranor becomes the boundary between ordinary failure and actual erasure.

### Question 8

When a new character is born, **how much is inherited from their parents and how much is generated by the world?**

For example: appearance, elemental traits, personality, talents, social role, relationships, abilities, destiny, and weaknesses.

## Turn 4fede332-c080-4753-b6fc-687f375eeb25

### User

I just want to... Okay. How much inherited by that. Okay. Now we are getting into the more of the architecture behind the characters, right? So the characters, they are put together from different background pieces. A background piece could be an attribute, like is strong. But it could also be is funny, or is loved. A background piece could also be is fast, is a good climber, is a good speaker, has a green thumb. Okay. So there's in all the important parts of a role-playing game, and that I would say is combat, trickery, aid, and something social. Something social.So from all these categories, there are many, many different skills. I could say skills, abilities, traits? Traits, maybe. And they have to do with how good with magic, how good at hunting, how good at being sneaky. All these traits, they are just traits that someone can have or cannot have. So they're pretty much qualities. And from both parents, qualities are taken: one third, one third of random qualities of both parents, each parent, one third of each parent is taken to the new being, and then the last third is filled with new random traits. And things like personality, that is, personality should be based on these traits, as well as appearance. Someone very strong appears very strong, of course. And yeah. And the social role should be based on the traits as well. So if someone has many traits that are good for a hunter, then they will be having the role of a hunter. If someone has a lot of traits of a whore, then they will be a whore. Relationships? I don't think we need relationships, or we could. We could make a family structure, relationship network, of course. The parent of the family's friends, our friends for the new being as well. So the network carries over kind of. And I think that the destiny and the weakness, of course. The weakness, I don't know. We don't need to focus on weaknesses. But the destiny, I think, is, of course, also based on the traits in some way, or also on the role, of course. So that it fits together in a way, so that it doesn't feel super weird that the hunter has to go and gather some berries in their destiny.

### Assistant

That gives the character system a strong generative foundation.

A character is assembled from many discrete **traits** or **qualities** rather than from a conventional stat sheet.

Traits can describe almost anything meaningful about the person:

- physical qualities such as strong, fast, agile, enduring, good climber
- practical qualities such as good hunter, good gardener, good crafter
- social qualities such as funny, loved, persuasive, charming, intimidating
- mental qualities such as observant, clever, patient, curious
- magical or spiritual qualities
- combat qualities
- trickery or stealth qualities
- supportive or aid-oriented qualities

The important thing is that these are not separate from the character's identity. They are the pieces from which the identity emerges.

For now, the broad gameplay families are:

**Combat**  
Fighting, defending, hunting dangerous creatures, physical confrontation.

**Trickery**  
Sneaking, stealing, deception, climbing, bypassing obstacles, ambush, perhaps traps.

**Aid**  
Healing, gathering, crafting, survival, helping others, maintaining the settlement.

**Social**  
Speaking, entertaining, seducing, mediating, leading, teaching, building relationships.

A person can of course have traits from several families.

### Inheritance

A new person receives roughly:

**⅓ of their traits from one parent**  
**⅓ from the other parent**  
**⅓ completely new traits**

So children resemble their parents mechanically and visibly, but every generation introduces variation.

Those inherited traits then influence almost everything else.

**Appearance** emerges from traits.  
Strong characters physically look strong. A frail character looks frail. Traits should visibly manifest rather than exist only as hidden modifiers.

**Personality** emerges from the combination of traits rather than being generated as an unrelated personality template.

**Social role** emerges from aptitude.  
Someone whose traits strongly favor hunting naturally becomes a hunter. Someone whose traits favor entertainment, sexuality, social connection, or whatever other occupation exists in that community would naturally gravitate toward that role.

**Relationships** inherit some social structure.  
A newborn enters an existing network rather than appearing socially blank. Their parents' family, friends, allies, enemies, clan ties, and acquaintances provide the beginning of their own social world.

**Destiny** is generated in response to the person they actually are.  
It should fit their traits, abilities, role, community, and circumstances. A hunter's destiny should generally emerge from possibilities that make sense for that person rather than randomly assigning them something disconnected.

This also means the procedural destiny system should not generate quests first and then force characters into them. It should read the character and the world and ask:

**"Given who this person is, what kind of life could unfold from here?"**

### Question 9

How do characters **gain new traits during their lifetime**?

Can someone become a good climber simply by climbing often, become brave through surviving danger, become loved through relationships, learn healing from another person, and gradually change what kind of person they are, or are most traits relatively fixed from birth?

## Turn 2a8d6609-c906-4947-8b2b-ecbd7b6e0fed

### User

And that is a perfect opportunity to give the side quests not only the function to support the character on the way to their destiny, but also to reward and add traits to this character. For example, if a side quest, like you say, if a side quest includes a lot of climbing, they will be rewarded the trait of climber, and so on. If the side quest includes learning about herbs, then maybe there is a trait as a consequence that is knows about herbs. That can be a trait. Knows about this language, can be a trait. Knows about this element, can be a trait. Knows about magic, can be a trait. So yes, there we have the place and a good way to develop the character during their lifetime.

### Assistant

That gives side quests a second structural purpose.

They do not merely help the character approach their destiny. They **change who the character becomes**.

A side quest can reward a new trait because of what the character actually experienced during it:

- repeated climbing → **Climber**
- studying plants → **Knows Herbs**
- learning another tongue → **Knows Language**
- investigating elemental phenomena → **Knows Element**
- surviving magical encounters → **Knows Magic**
- protecting others → perhaps **Protector**
- negotiating disputes → perhaps **Mediator**
- tracking animals → **Tracker**
- enduring danger → perhaps **Steadfast**

The important part is that the reward grows naturally from the activity itself. The character does not complete an unrelated quest and then pick a perk from a menu.

This means the destiny tree can deliberately contain side paths that prepare the person for what lies ahead. If their eventual destiny requires crossing a cliff, understanding an old language, calming a dangerous animal, or resisting strange magic, earlier side quests can gradually build the traits needed for that future moment.

So the character's life becomes:

**Inherited traits → role and destiny → experiences → new traits → changed possibilities → further destiny**

### Question 10

Should traits be **binary**, where a person simply *has* or *does not have* a trait like **Climber**, or should traits have degrees such as **Novice Climber → Climber → Excellent Climber**?

## Turn 606b1baa-4ed7-4280-a168-5f0397e02f68

### User

Yeah, I really had that thought. And that is totally something that could be played with. But I think we start with just have it or have it not. Because that way we can have more, more different things, more diversity, instead of vertical progression. I would like to focus on horizontal progression and just make someone more diverse instead of making someone specialized on something niche.

### Assistant

Then traits are **binary qualities** for now: a character either has a trait or does not.

That keeps progression horizontal.

A character does not become *Climber 7*. They become a person who is:

- Climber
- Knows Herbs
- Good Speaker
- Tracker
- Knows Magic
- Strong
- Funny
- Sneaky
- Good Swimmer

Their development is therefore about becoming **broader and more complex**, not increasingly optimized around one narrow function.

It also makes inheritance more interesting. Parents pass down recognizable pieces of themselves rather than numerical stat values.

### Question 11

Can characters **lose traits**, or do traits normally remain once acquired?

For example, can someone cease to be **Loved**, forget a language, lose their confidence, become physically weaker, or lose knowledge after trauma or neglect?

## Turn d907309c-eb46-4907-9a76-24a4097c0f4b

### User

That's cool. I would say. I would say we don't do that. I would say there's not much interest in losing traits in general in games. Even if it's not my character, and it is logical to maybe cease to be loved. But this game is about... it's not so much about the consequences. It's not so much about doing the right thing or not. It's more about that everything that I do can be the right thing. And it doesn't need that drama, that losing the confidence or becoming physically weaker. It happens. We already have the punishment for not going home when you're tired and becoming something that is not an individual anymore, or becoming a corrupted monster that has to be put down with the others. So there's already consequences, dire consequences, for some actions. But I think they have more impact and they are more simple than losing traits. So no losing traits.

### Assistant

Then traits are **persistent acquisitions**.

Once a character has gained a trait, it remains part of who they are.

The game is not interested in constantly eroding the player’s progress through:

- forgotten skills,
- decaying attributes,
- lost confidence,
- weakened competence,
- social traits disappearing because of hidden maintenance rules.

That would shift the game toward punishment and optimization.

Instead, Morkahja treats most actions as potentially meaningful paths. A character’s life accumulates qualities rather than constantly defending them from decay.

The serious consequences already exist elsewhere:

- losing touch with destiny,
- withdrawing too far from communal purpose,
- exhausting oneself through aimless existence,
- dissolution of individuality,
- corruption into something hostile to the world.

Those consequences are larger, clearer, and more mythic than losing **Climber** because the character has not climbed recently.

So the character system becomes strongly cumulative:

**birth traits → inherited traits → lived experiences → additional traits → increasingly unique person**

### Question 12

How many traits should a newly born character roughly start with?

Do you imagine something like **5–10 defining traits**, **20–30 traits**, or potentially a very large collection where each person is made from dozens of small qualities?

## Turn a9de54df-51ea-4bea-9bd6-8cca80a5a646

### User

I like to keep it simple. I really like to keep it simple. But it has to be enough to have a random randomness. I would say 27. 27 traits for a newborn. And that is nine from each parent.

### Assistant

Then a newborn starts with **27 traits**:

- **9 inherited from one parent**
- **9 inherited from the other parent**
- **9 newly generated random traits**

That preserves the one-third / one-third / one-third structure exactly.

Twenty-seven also gives enough pieces for a person to feel distinct without turning the character into a spreadsheet. Because traits are binary and horizontal, two characters can share a role while still being built very differently.

### Question 13

Should those 27 starting traits be **completely free to distribute across all trait types**, or should every newborn receive some basic spread across **Combat, Trickery, Aid, and Social**, so that nobody is born almost entirely concentrated in one area?

## Turn ca350b73-ff7e-4f50-b019-faedb984f159

### User

I think completely random. Completely random. It's just shuffle the deck, draw the cards, 27. Draw the cards from the parents first. Yeah. Draw the cards, give them nine, nine, nine cards. And the new cards are from all trade types. And then after that you look, okay, what type is he? Is he more of a fighter, more of a trickster, more of an aid, more of a psychosocial. And then based on that, choose a role. And then based on that, and so on. And in the end it becomes a side quest, and it becomes a destiny. And then the destiny and the side quest, they actually, and the role as well, they actually add content into the game. They add the places, they add the creatures, add the items. It's a complete set. The new being brings everything with it. Everything is there, is added to the world, everything that they need. The individual thing is just how they will achieve this. What do they have to do to get their side quest done and to get to the destiny and to fulfill their role.

### Assistant

Exactly. That makes the birth of a character a complete **content-generation event**, not merely a character-generation event.

The sequence becomes:

**1. Draw the person**
- 9 random traits from parent A
- 9 random traits from parent B
- 9 random traits from the full trait pool
- No balancing
- No guaranteed category spread
- Whatever combination appears is accepted

**2. Read the person**

The game examines the resulting 27 traits and determines what kind of person has emerged.

They may lean toward:

- Combat
- Trickery
- Aid
- Social

Or they may be an unusual mixture.

**3. Derive their social role**

The role follows from who they actually are.

A person with many hunting, tracking, strength, endurance, and wilderness traits may become a hunter.

Another character might emerge as a healer, scout, craftsperson, storyteller, warrior, entertainer, spiritual figure, or something much stranger.

**4. Generate their destiny**

The destiny is built from:

- their traits,
- their strongest tendencies,
- their role,
- their culture,
- their settlement,
- existing world conditions.

It therefore belongs specifically to this person.

**5. Generate their side quests**

The side quests prepare them for the destiny and expand their identity through new traits.

**6. Generate the required world content**

This is the crucial part.

The new character arrives together with everything their life requires.

If their destiny involves:

- a particular animal, that animal enters the simulation;
- a strange tree, an appropriate location is generated;
- a sacred object, that object gains an origin and physical existence;
- another person, that relationship or person must exist;
- a cave, shrine, ruin, river, herb, creature, trail, artifact, or mystery, the world gains the necessary conditions for it.

The character effectively carries a **bundle of future reality** into Morkahja.

The system does not predetermine exactly how the player reaches those things. It establishes that the ingredients exist.

So the procedural model becomes:

**Traits → Character → Role → Side Quests → Destiny → Required World Content**

Then actual play supplies:

**Choices → Routes → Encounters → Relationships → Consequences → History**

That difference is important. The generator creates the **possibility space**. The players create what actually happens.

### Question 14

When a newborn's destiny generates new world content, should that content always appear somewhere **outside the currently explored world**, so discovery continually expands the map, or can a new destiny also reinterpret and reuse existing places, creatures, people, and objects already present in Morkahja?

## Turn b88a9d87-6545-4123-8898-0a0ee4af1525

### User

Yes, I already mentioned that somewhere, and that is very important because we are trying to not. So the issue is if we just add it outside, we will expand it further and further. But the destiny locations will also be further and further away from the village. So it will be taking longer and longer to reach locations, and everything that is before that will be abandoned. So we have to, we have to repopulate some of the nodes. For example, when the bear is dead and it's gone, they took it away. They took all the parts, and the skeleton is taken away by the wolves, or whatever. Or maybe someone took all of it. That bear is not there anymore. So his node, his place, is vacant, and his place can be repopulated with something else. There can be a special flower growing where the bear died. There can be, yeah, there can be an item that someone lost there when they took away the bear and they lost it there, but it was an important item from the family, and now we have to pick it up. So this way nodes can be repopulated. Caves can be repopulated. Someone moves in. Some troll just moved in the cave that was before just a cave, and someone had to find a special mushroom in that cave. So that way there we have a lot of opportunity to reuse the nodes, but we also have to make sure that each destiny does expand the world, so that there is new content and there is more to discover in our horizontal progression world, literally horizontal progression, because we are progressing the horizon further and further away. But we do that in a way that allows us to keep a balance, so each adventure is in a way similar in size. It's also important that we don't need to start with something very close. We can already in the beginning have a trail to the mountains and have the destiny far away and make a place far away, and there's a lot of paths between that might be populated with random encounters or things. But important is that it can be far away already. Yeah.

### Assistant

That gives the world-generation system a very clear rule:

Morkahja should **expand and recycle at the same time**.

New destinies should not simply push content farther and farther from the settlement, because that would create an ever-growing dead ring of abandoned old locations and increasingly long travel times.

Instead, the world uses **reusable nodes**.

A node can change meaning over time:

- a bear's den becomes vacant after the bear is killed,
- later a rare flower grows there,
- later someone loses an important family object nearby,
- later another creature moves into the same area,
- an empty cave later becomes inhabited,
- an old quest location becomes relevant to a completely different destiny.

The physical place persists, but its **current narrative function changes**.

At the same time, every destiny should contribute at least some genuinely new world content. Otherwise the world would eventually become static.

So the system balances two forces:

**Repopulation**
Existing places gain new creatures, items, events, inhabitants, resources, mysteries, or purposes.

**Expansion**
New destinations, routes, regions, landmarks, and environments are periodically added beyond what is already known.

That creates literal horizontal progression. The world does not become stronger. It becomes **wider, denser, and more historically layered**.

Distance should also remain flexible. A destiny does not need to begin close to home. Even an early character could have a destination far away in the mountains, with the journey itself becoming part of the adventure through paths, encounters, discoveries, and intermediate nodes.

The important balancing rule is therefore not "new content must be close." It is:

**Each destiny should produce an adventure of manageable scope, regardless of where its important locations are.**

### Question 15

How should **time** work in Morkahja?

Should the world continue running in real time when nobody is playing, with characters aging, children growing, food being consumed, seasons passing, and settlements changing continuously, or should time mainly advance when players are actively present?

## Turn 532653fb-0361-4b58-8673-032c4bfb5c82

### User

If no one is active, it continues, but it can go slower. But it should be a simulation, settlement simulation. But if no one is active, also no one is ready to exploit that our interests, or wrong. Everyone is doing the right thing, like a computer should, and just to maintain the settlement and community. So it can slow down when no one's online, of course, but it would be nice to have progress.

### Assistant

Then Morkahja runs as a **persistent settlement simulation**, even when no players are present.

When players are offline:

- characters continue their roles,
- food is gathered and consumed,
- settlements are maintained,
- relationships continue,
- children can grow,
- knowledge can spread,
- ordinary exploration can still happen,
- the community keeps itself stable as far as its resources allow.

But the simulation can run at a **reduced speed** when nobody is online.

That solves two problems at once. The world keeps feeling alive and capable of progressing, but it does not race forward while nobody is there to participate.

It also fits the distinction we established earlier: AI-controlled characters behave sensibly and communally. They do not deliberately sabotage the settlement, chase risky destinies, or exploit systems. They mostly maintain life, fulfill roles, explore within safe limits, and preserve the community.

Player presence is therefore what introduces **ambition, risk, unusual choices, destiny progression, and major change**.

### Question 16

How should **aging and growing up** work?

When a new being is born, do you imagine them beginning as a child who physically grows over time before becoming playable, or should births effectively create a new playable adult after some abbreviated growth period?

## Turn 03a69cf1-c225-4b3e-850a-649f825c93ea

### User

It's a child who physically grows over time, and in the becoming of age, it will unlock more and more of the birth traits that it has. It is, of course, in the beginning just in the community. It can be played, and it can collect traits already as a child. But it is, of course, much weaker, much more fragile, even if it has a trait that it is strong. It is still quite weak in comparison. Yeah, but so in the time that it grows up, it unlocks more and more of the traits. It might start with nine of them, nine random ones of its own little pool, and then unlock the others with each step in the aging process until adulthood. And when it's adult, then it has all its 27 traits. Yeah.

### Assistant

Then childhood becomes a real playable phase rather than a waiting room before the "actual" character begins.

A newborn has all **27 birth traits latent inside them**, but only a portion is expressed at first.

A simple structure could be:

- **Childhood begins with 9 active traits**
- additional traits unlock gradually as the character ages
- by adulthood, all **27 inherited/generated birth traits** are active
- traits gained through lived experience can already be added during childhood
- physical capability remains age-limited regardless of traits
- a child with **Strong** is strong for a child, not equivalent to a strong adult
- children are more fragile and naturally more dependent on the settlement

So aging does not increase numerical stats. It **reveals the person who was already latent within the child**.

That also means childhood itself can influence adulthood. Two children born with identical 27-trait pools could reach adulthood with different additional traits because different players inhabited them, explored with them, learned things, formed relationships, and experienced different events.

### Question 17

When does a character's **destiny** begin?

Does a child already have a destiny that can slowly reveal itself through childhood, or is the full destiny only generated or activated when they reach adulthood?

## Turn e18a6f88-7d1e-45b1-be69-dcb5d902f524

### User

And of course, the character's destiny begins when adulthood begins. Before that, it's just exploration, discovery, tasks in the community, free play, so to say.

### Assistant

Then childhood is deliberately **pre-destiny life**.

Before adulthood, the character has no personal destiny to pursue. Their gameplay is centered on:

- exploration,
- discovery,
- learning,
- helping with community tasks,
- social play,
- experimenting with the world,
- gaining additional traits,
- gradually unlocking their 27 birth traits.

This makes childhood freer and less directional than adult life.

At adulthood, the character crosses an important threshold:

**all 27 birth traits are active → their adult role is understood → their destiny begins**

That moment effectively becomes the point where the world says: **this is who this person has become, and this is where their life now wants to go.**

### Question 18

Is the character’s **social role** also decided only when adulthood begins, or can children already drift toward roles through the tasks they perform and the traits they reveal while growing up?

## Turn 2709d813-6216-462d-92d8-2c7a571bd2d9

### User

social role also when adulthood.

### Assistant

Then the structure is clean:

- **Childhood:** no destiny, no social role.
- Children explore, learn, help, play, form relationships, gain traits, and gradually unlock their latent birth traits.
- **Adulthood:** all 27 birth traits are active.
- Only then does the game evaluate the whole person.
- From that complete trait set, it determines their **social role**.
- From the role, traits, culture, settlement, and world state, it generates their **destiny and side quests**.

So adulthood is the moment where the character stops being pure possibility and becomes a defined participant in society.

### Question 19

How should **social roles themselves work mechanically**?

Is a role mostly a responsibility, such as Hunter meaning “help keep the village supplied with meat,” or does taking on a role also grant special abilities, tools, access, knowledge, privileges, or unique interactions?

## Turn 5aebd504-8772-4924-ad45-fdabaa400e71

### User

I'm thinking of unique interactions. It's an interesting, it's an interesting word. Social roles instead of mechanical. They are a bit like a calling, a bit like something underlying. And they give unique interactions. So if my role is... we really need to know which roles we have with the social role, for example. It would just unlock interactions with others that are otherwise impossible. Or it will unlock something for both of the players. I just noticed that everything might be a little bit too abstract. So yes. It grants special abilities, absolutely. That is a little bit like the hero in Dota 2. You get different skills and acts and knowledge, yes. Probably you get a hunter probably gets a skill where he can track prey. So he sees the tracks in the environment.

### Assistant

Then social roles are not just jobs. They are **callings that change what the character can perceive and do**.

A role gives the character a distinct set of verbs.

A **Hunter**, for example, might gain interactions such as:

- seeing and interpreting tracks,
- identifying disturbed vegetation,
- reading animal behavior,
- recognizing calls and scents,
- preparing certain traps,
- harvesting an animal in ways other characters cannot,
- communicating useful hunting information to others,
- noticing signs in the environment that are effectively invisible to someone without that role.

The important part is that the role does not merely say “+20% hunting.”

It changes the actual game.

Two players standing in exactly the same forest might literally experience different possibilities because one is a Hunter and the other is not.

The same applies socially. Certain combinations of roles could unlock interactions between two characters that neither can perform alone.

This also makes the role somewhat comparable to choosing a Dota hero, except it is generated from the person rather than selected by the player.

### Question 20

What are the **core social roles** that should exist in the first version of the village?

Not every possible occupation in Morkahja, just the fundamental callings that should be strong enough to define a character’s gameplay.

## Turn 7a8bf82e-4245-494b-a2b1-6b18a67ea149

### User

It depends on the culture that we're in. I think we will have a village for each, for each race, for each element. Yeah, because it is so early, the people haven't found each other yet. So depending on what culture there is, there are different social roles. These are details we can figure out later. I also had thought that with the roles, that they kind of have an effect on side quests as well. So that I will be rewarded traits that are actually even, or sometimes I will be rewarded traits, that are even strengthened me further in the role that I'm having. So that the hunter has a partly hunting-related or similar destiny, and therefore gets traits and rewards in that category, roughly in that category.

### Assistant

Then social roles are **culture-specific callings**, not one universal class list shared by all of Morkahja.

At this early point in history, the four peoples have not yet encountered one another. Each begins with its own isolated settlement and its own way of organizing society. A Verdani village therefore develops different roles from a Rokur, Aevis, or Grimnir settlement.

The generation chain becomes:

**Traits → cultural interpretation → social role → role abilities/interactions → destiny → side quests → additional traits**

The role also influences character development. A Hunter will tend to receive at least some side quests and destiny material connected to hunting, wilderness, animals, tracking, survival, or adjacent areas. Those experiences can then add more traits that reinforce that calling.

It is still horizontal progression, because the Hunter does not become **Hunter Level 12**. They become a Hunter who also knows herbs, understands wolves, can climb, recognizes weather signs, knows a particular valley, can prepare certain hides, and so forth.

So over a lifetime the character develops a recognizable shape without being locked into a narrow build.

### Question 21

How much control should players have over the **physical development of their settlement**?

Can players decide to build a new house, wall, workshop, shrine, bridge, storage building, road, or other structure and choose where it goes, or should settlement construction mostly emerge automatically from the needs and decisions of the simulated community?

## Turn f499dd18-cb30-4b04-8057-289b2fad5f9e

### User

It's not a building game. And the player has no saying in how the village, how the community develops. Of the community develops by itself. This is very important that this is an RPG, or something like that, something similar. And it is an open world to everyone. So it's multiplayer. There is not one player that decides anything, where anything should be or something. I don't know. How is this question even? But he is.

### Assistant

You're right. That question drifted into colony-builder logic, which is specifically not what this game is.

The rule is:

**The player controls a person, never the settlement.**

The village is an autonomous simulation. It decides for itself when houses are needed, where structures appear, how resources are organized, how the settlement expands, and how communal needs are addressed.

Players influence that world only through what their temporarily inhabited character actually does inside it. A hunter brings food. An explorer brings knowledge. A healer helps people. A character completes their destiny. Those actions affect the community, but nobody receives a god-view construction interface or becomes mayor of the simulation.

That is particularly important because this is a **shared multiplayer world**. Nobody owns the village. Everyone is temporarily one person living inside it.

### Question 22

We have established that almost all meaningful progression belongs to the characters, community, and world. **What, if anything, should permanently belong to the player account itself across all the different people they inhabit?**

## Turn b5d78ee2-e851-4993-a9e1-f4ba83873ceb

### User

So what I think would be nice for the player, if I play a game like this, is pretty much a collection of what I have done in the game. So the player can have, like, a timeline of achievements inside the game, or of activities inside the game. They can have something like achievements, where they get a sense of progress outside the game, so in their player account, kind of. But on one side I think that it is a good thing for players; many players like that. On the other side, I'm not sure if that is even important and favorable for this game. It might be unnecessary, and it might be an immersive meta layer to the game that is just taking resources from developer and player at the same time. So I think we don't give the player anything that permanently belong to the player. And if we decide to give them something, then it will be a very simple diary where he can see what he has done in the game, where some of his actions are written down and saved for him to look and show, and have a reminder of what happened in the game.

### Assistant

Then the default should be: **the player account owns nothing that affects the game world.**

No account stats, no permanent abilities, no unlock tree, no inherited power, no meta-currency. That keeps the player from slowly becoming the real persistent character.

If there is any persistent account layer at all, it should be purely reflective:

- a simple personal diary or timeline,
- notable characters the player inhabited,
- places they discovered,
- destinies they helped complete,
- unusual events they witnessed,
- perhaps major communal moments they participated in.

It does not make the next character stronger. It only preserves the player's **memory of having been there**.

And even that should probably remain optional and very lightweight, because the game does not need a second progression system competing with the world itself.

### Question 23

When a player logs out of a character, **what exactly happens in that moment inside the world?**

Does the character immediately return to AI control exactly where they stand, or should the game try to bring them back toward safety, home, or ordinary life before handing them back to the simulation?

## Turn 8889d78d-b7b8-429c-8a48-f34cf5d65979

### User

So there we have to make a quick distinction about if the player logs out manually, or if the player disconnects by whatever reason, for whatever reason. So if the player decides to leave, then the character will make their way back home. If the player is disconnected, or the game crashes, or whatever happens. If the player is logged out without known reason, then the character will first wait where it is, and only move back home when it's time, when it still has enough time to reach home without getting too tired. Yeah, that's pretty much, I think that's pretty much covering.

### Assistant

Then logout has **two different handoff states**.

**Manual logout:** the player has consciously finished the session. The character immediately returns to AI control and begins making their way home, returning to ordinary community life.

**Unexpected disconnect:** the character does not immediately wander away. They remain where the player left them for a while, preserving the possibility that the same player reconnects and continues.

The AI watches the character’s remaining endurance and distance from home. Once waiting any longer would risk leaving too little time or energy to return safely, the character stops waiting and begins the journey home.

So the character effectively thinks:

**“They might come back. I’ll wait.”**

And eventually:

**“I cannot wait any longer and still make it home.”**

That fits the game nicely because the system responds to the *reason* for absence rather than treating every logout identically.

### Question 24

While a character is in that **waiting period after an unexpected disconnect**, should that character remain reserved for the disconnected player, or can another player choose and inhabit them before they decide to return home?

## Turn 7b1cc3da-2002-441f-9ce2-377beb5ca3f7

### User

That's a good question. So, in multiplayer games, when someone disconnects, it often can be frustrating for the other players if they're playing together. We could either have a stand-in system where people can flag themselves as a stand-in. So, for example, when I'm queuing up for a place in the queue, I can say either I want to only queue up for a full experience, or I also want to queue up for jumping in in case someone disconnects or has to go quickly, or whatever, so that I can then immediately, so that I kind of have a bigger chance, have a bigger chance to find a gameplay moment earlier when I also queue up for a stand-in situation. But it can also be that the player that disconnected comes back and I go back to the queue and they take over again. So I think that's quite a smooth solution there if there is a queue. If there is no queue, the character, of course, can remain reserved for the disconnected player.

### Assistant

Then disconnected characters have a **stand-in system**, but only when there is actually demand for playable slots.

A player entering the queue can choose whether they are willing to:

- wait only for a normal available character, or
- also accept temporary stand-in control of a character whose player disconnected.

If they opt into stand-ins, they may get into the game faster.

When a disconnect happens during group play, an available stand-in player can temporarily inhabit that character and keep the adventure moving. If the original player reconnects, they regain the character and the stand-in player returns to the queue.

If there is no queue and no need for a replacement, the disconnected character simply remains reserved for the original player during the waiting period.

That makes the handoff flexible without treating a disconnect as abandonment.

### Question 25

When a **stand-in player** takes over, how much information should they receive about what was happening immediately before the disconnect?

Should they get a short automatic recap of the current situation, relationships, destination, and immediate goal, or should they simply drop into the character and figure it out from the world and the other players?

## Turn 8396c3bc-e526-4a31-9bab-e5d6b2c66d5a

### User

This could be something where when the queue pops, it also shows the character. When the queue pops, it shows the character and what they have been doing, and it pops for several people, and they can agree or disagree, but there's a time running. If they don't agree or disagree in that time, they go back to the queue. If they agree, they will wait until everyone has agreed or disagreed to take this place. And when all of them have done it, the first one in the queue will get the slot. So everyone gets a little insight in what was happening there in the world. So that's in the menu, the queue pops. They are probably in the game already when they are queued. They're just in a viewer mode, spectator mode, so they can see what's happening in the world. They can move around, they can fly around kind of, but they cannot interact with it. So that's when they are queued. They're already in the game, but they're just waiting to occupy. And while they're waiting, there could be more information, like they could read about things. Maybe they could click on a building and see what kind of building it is. There's like a lore mode as well. They can click on characters and see what they are about, see the character sheet kind of spectator mode, while queued. And then, yeah, so they get a little recap before they accept the jump in or the stand in.

### Assistant

Then the queue itself becomes part of the game world rather than a dead menu.

While waiting, the player is already **inside Morkahja in spectator mode**.

They can:

- move or fly around freely,
- watch what is happening,
- inspect buildings and learn what they are,
- inspect characters and see their traits, role, current situation, and character sheet,
- read lore and local information,
- understand the state of the settlement before inhabiting anyone.

So waiting becomes a kind of **lore and observation mode**.

When a stand-in opportunity appears, the queue pop shows the player the actual character and a short recap of what is happening:

- who the character is,
- where they are,
- what they were doing,
- who they are with,
- what the immediate situation is,
- what their current objective or direction is.

The offer can go to several queued players at once. Each has a short timer to **accept or decline**.

If they do nothing, they simply remain in the queue.

Once everyone offered the slot has responded, the earliest eligible player in the queue who accepted gets the character. Everyone else continues waiting.

That gives stand-ins context before they commit, while also letting the queue itself teach players about the world.

### Question 26

When someone is in **spectator mode**, how much of the world should they actually be allowed to see?

Can they freely fly anywhere, including completely unexplored places and destiny locations, or should spectator mode be limited to areas and information that the community has already discovered?

## Turn 2dd9a009-ad75-459f-814e-9864ad9cb221

### User

I think they should only be able to follow along other characters. So they maybe a click of characters that are on the screen and then they follow along those characters. So no free fly, only follow.

### Assistant

Then spectator mode is much more constrained and much more in-character for the game.

The queued player does **not** become an invisible flying camera.

Instead, they spectate through existing lives.

They see a set of currently active characters and choose one to follow. The camera stays with that person and lets the spectator observe their journey, surroundings, interactions, and current situation.

That means:

- no free exploration,
- no revealing hidden areas,
- no scouting ahead for destiny content,
- no bypassing the discovery system,
- no omniscient map knowledge.

The spectator learns about Morkahja only by **watching people who are actually there**.

They can still inspect the followed character, read about them, understand their role and traits, and perhaps switch to another active character if they want to watch a different part of the world.

That makes the queue feel almost like watching a living anthology of ongoing adventures.

### Question 27

While spectating another player, should the spectator be able to **hear their proximity voice chat and conversations**, or should they only see the action without hearing private player communication?

## Turn 9ec1ef2f-f169-490e-ab17-19f3d1f0a641

### User

I was expecting they, of course, don't hear the proximity voice chat and also. Sure, we will have the proximity voice chat. Sometimes it is a little bit difficult to roleplay certain characters when the voice doesn't really fit. So I think we will take away this voice chat and make the game simple enough that there's no big need for communication in the way of talking to each other. We do have this fact that knowledge is handled in very different ways in this world and in these communities. So we will probably not have the need to talk much.

### Assistant

Yes. Then we should remove proximity voice chat from the concept.

That actually strengthens the design in several ways. Players inhabit many different characters across ages, bodies, cultures, and personalities. Their real voice would constantly bleed through that identity. Removing voice keeps the character itself in the foreground.

It also means communication should be built into the RPG systems rather than depending on players talking over Discord-style voice.

Knowledge already works this way. A character does not necessarily need another player to verbally explain, “I saw a bear north of the river.” That information can enter the culture's knowledge system and become accessible through the appropriate in-world mechanisms.

Direct interaction between players can therefore rely on **simple contextual interactions, gestures, role abilities, signals, and perhaps a limited set of expressive actions** rather than unrestricted speech.

And spectators hear no player communication because there isn't any voice channel to overhear. They simply observe the character's visible actions and the world.

### Question 28

Should players be able to **type freely to one another at all**, or do you want communication itself to remain almost entirely inside the game's interaction system, with gestures, contextual actions, signals, and role-specific interactions replacing normal text chat too?

## Turn 09f8ccb6-746a-4796-8090-765e9dfecf0e

### User

Yeah, I never thought. I never said anything about a text chat, so no, there's no text chat. Like you say, the game's interaction system, textures, context actions, signals, and role-specific interactions are replacing all the text chat. And so, yeah.

### Assistant

Then communication in Morkahja is fully **diegetic and action-based**.

There is:

- no proximity voice chat,
- no text chat,
- no out-of-character communication layer inside normal play.

Players communicate through the character and the world:

- gestures,
- contextual actions,
- signals,
- movement,
- pointing,
- role-specific interactions,
- culturally appropriate knowledge systems,
- shared actions that both players can understand from context.

That means communication itself becomes part of roleplay rather than a parallel chat system sitting on top of it.

It also helps preserve the identity of the character. A player inhabiting a child, a hunter, a healer, a Grimnir, or a Verdani does not suddenly speak in the same external voice and tone across every body.

### Question 29

How expressive should the **gesture and contextual interaction system** be?

Do you imagine a small universal set of very readable actions, like point, follow me, stop, help, yes, no, danger, come here, give, take, or should each culture and social role have a much richer and more specialized interaction vocabulary?

## Turn 86e9aeca-0ff7-4ccf-83f2-0d8b1d0fb0e3

### User

I think that the interactions would never be so shallow. Yes, of course, it could be a call for working together. But the important thing is that it always depends on the relationship, on the role, on the social role, on, if there's knowledge that can be shared. If I have the question and the other one has the answer, then there's room for interaction. So it should always be connected to how the traits, how the roles, how they... I think we have to use the traits not only for specifying who the character is, but also specifying what the character knows. For example, the knowledge could be a trait. So each piece of knowledge could be a trait. What I mean is that I want it to be that when I have seen the bear, I get a trait: knows where the bear is. Maybe at this point we can't really call it a trait anymore, but maybe it's still okay. If I have this trait, I then have the possibility to transfer this knowledge. If someone has the question, needs to know where the bear is, if someone has this trait, then they fit together, and in that situation they are able to exchange this knowledge. So they are able to connect to each other in a way where they exchange this knowledge, and that's depending on what race or what culture they are. They will exchange this knowledge in a different way. But yeah, so that's how it should work. If I have a trait inside me that is a match with a trait inside you, then we can interact in the way that these traits are interacting with details, details, I don't know what we could call them, traits? I'm not sure. Shards? Maybe just shards? Knowledge shards, or spirit shards. One shard. Each shard has some knowledge in there. Well.

### Assistant

Yes. I think this is a really important refinement.

What we have been calling **traits** are starting to split into two different kinds of things:

**Traits**
Persistent qualities that describe what a person *is*.

- Strong
- Funny
- Climber
- Hunter
- Persuasive
- Knows Herbs
- Knows Magic

**Shards**
Discrete pieces of lived knowledge, memory, or situational understanding that describe what a person *knows*.

- knows where the bear was seen
- knows that the northern cave contains mushrooms
- knows that a certain person carries the missing family object
- knows that the river crossing is dangerous
- knows that a shrine reacts to fire
- knows that someone in the village is looking for a healer

A shard can be gained through experience.

Then interaction becomes a **match between needs and shards**.

One character has:

**Needs: location of the bear**

Another character has:

**Shard: knows where the bear was seen**

That creates a valid interaction between them.

The exact form of that interaction depends on culture, relationship, role, and perhaps other traits.

A Rokur might convey it through hearth-story, gesture, marks, or remembered directions.

A Verdani might share it through water-memory.

An Aevis might resonate or encode it through crystal or aether.

A Grimnir might use a memory stone, physical marking, or crafted representation.

So players are not choosing dialogue lines from a generic social menu.

The game is effectively asking:

**“What meaningful things exist between these two people right now?”**

And only those interactions appear.

That makes communication much deeper because the interaction possibilities are generated from the actual state of both characters.

### Question 30

When one character transfers a **shard** to another, should the original character keep it too, meaning knowledge can spread through the community, or can certain shards be transferred or lost so that only one person possesses them at a time?

## Turn cc9b2ef3-237c-4de8-9898-6c6e391e2199

### User

No, of course. The shard is not transferred. The shard is duplicated. It is only transferred when it is given to the collective memory, to the memory well. There we can say that the individual can get rid of shards. Okay. Yeah. And can lighten themselves.

### Assistant

Then shards behave more like **copies of memory**, not objects.

If I know where the bear is and share that with you, I keep my shard and you gain your own copy of that shard.

So knowledge can spread person to person without diminishing the source.

The special case is the **collective memory**.

When a character contributes a shard to the culture's communal memory system, they can choose to relinquish it personally. In that case, the shard leaves the individual's active mind and becomes part of the shared cultural archive.

That gives the act a nice metaphysical weight:

**personal knowledge can be carried, shared, or laid down.**

And “lightening oneself” becomes an actual mechanic. A character burdened with many memories, observations, obligations, or pieces of knowledge can deposit some of them into the communal memory.

That also gives the collective memory systems a second purpose beyond information retrieval. They are places where individuals can **unburden themselves**.

### Question 31

Should every shard have a different **weight or burden** on the character, or is the idea simply that carrying more and more shards in general gradually makes the person feel mentally or spiritually heavier?


