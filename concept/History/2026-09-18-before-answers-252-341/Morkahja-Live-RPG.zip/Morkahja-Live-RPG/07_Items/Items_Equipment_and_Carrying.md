# Items, Equipment and Carrying

Items have a physical life in the shared world. They can be made, found, carried, exchanged, lost, repaired, consumed or transformed. Their continuing presence connects different people's tasks.

## Persistent objects

A bear has its claw before anyone accepts a task concerning it. After the bear dies, the claw can change hands and continue into other stories. A suitable object already held by a character can satisfy a later requirement.

Finishing an objective leaves its object in the world. Physical use determines its future: food is eaten, materials become part of another object, and equipment remains available for use or repair.

## Physical carrying

Objects occupy meaningful carrying arrangements. Bags hold small items; weapons, tools, bundles and large objects remain visible on the body. The loadout shapes the person's silhouette and affects what they can bring home.

Capacity is organized through logical body slots and containers. A weapon, ranged weapon, tool, food bundle, camping equipment or bag illustrates the kinds of loadout involved. Bringing a large find home can require choosing between items or seeking another person's help.

## Taking and equipping

Picking up a weapon is its equip action. Taking a replacement for an occupied slot leaves the previous item at that location. The panel displays the loadout; equipment changes happen through world actions.

An unfamiliar item is physically usable. Matching character qualities, Needs and circumstances open further contextual possibilities. Knowing an item reveals its Traits.

## Clothing and craft

Clothing comes from real material, labor and care. Garments, bags and other equipment express what the person has acquired and what their community can make. Their qualities can match a person's preferences or another task's requirements.

## Condition and repair

Equipment is **Okay** or **Broken**. Broken objects remain in the world and become unavailable for actions requiring them to function. Appropriate repair restores their previous condition and qualities.

A broken weapon creates a repair Need. The character can supply the requirements directly or seek someone with the relevant capability, tools and material.

## Makers, holders and knowledge

Crafting creates a Shard connecting an object to its maker. Reports of possession can identify its current holder. This knowledge travels through exchange and contribution to the cultural source.

Finding an unfamiliar spear can create a question about who made it or whose it is. The answer may be with its maker, an informed traveler or the communal source.

Taking another person's item is permitted without an automatic crime or social-penalty system. A missing spear can create a recovery Need for its former holder. Witnessed information and later exchange guide the search toward the current holder.

When several people try to take one object, the first successful physical interaction obtains it. Others see the object removed or carried by that person.

## A claw's continuing story

A hunter brings a claw home and exchanges it. Another person later needs the same claw and learns who holds it. The next step becomes obtaining it from that holder. The object's history connects the two adventures.

See [Crafting](Crafting_and_Item_Traits.md), [Trade](Trade_and_Exchange.md), and [Knowledge](../05_Knowledge/Shards_Memory_and_Cultural_Hubs.md).
